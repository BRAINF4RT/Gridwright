/**
 * Game extension: the things a game needs that are not drawing or moving sprites.
 *
 *  - Saves: values saved under a name survive closing the game. They are kept per game (and per save slot), in a file
 *    in the app's data folder, or in the browser's local storage when there is no desktop host.
 *  - Window: fullscreen, window title, hiding the mouse pointer, quitting.
 *  - Gamepad: buttons and sticks of the first connected controller.
 *  - Timing: frames per second, time since the last frame, time since the game started.
 *
 * The desktop app provides runtime.host: {loadSaves, saveSaves, setFullscreen, isFullscreen, setTitle, quit}.
 */
const ArgumentType = require('../../extension-support/argument-type');
const BlockType = require('../../extension-support/block-type');
const Cast = require('../../util/cast');

const iconSvg = '<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40">' +
    '<rect x="4" y="11" width="32" height="19" rx="9" fill="#fff" stroke="#0E1110" stroke-width="2"/>' +
    '<path d="M12 17v8M8 21h8" stroke="#0E1110" stroke-width="2.4" stroke-linecap="round"/>' +
    '<circle cx="26" cy="19" r="2" fill="#C4FF0E" stroke="#0E1110" stroke-width="1.2"/>' +
    '<circle cx="30" cy="23" r="2" fill="#30CBC0" stroke="#0E1110" stroke-width="1.2"/></svg>';
const blockIconURI = `data:image/svg+xml;utf8,${encodeURIComponent(iconSvg)}`;

const ON_OFF = ['on', 'off'];
const PAD_BUTTONS = ['A', 'B', 'X', 'Y', 'left bumper', 'right bumper', 'left trigger', 'right trigger',
    'back', 'start',
    'left stick', 'right stick', 'up', 'down', 'left', 'right'];
const PAD_INDEX = {'A': 0,
    'B': 1,
    'X': 2,
    'Y': 3,
    'left bumper': 4,
    'right bumper': 5,
    'left trigger': 6,
    'right trigger': 7,
    'back': 8,
    'start': 9,
    'left stick': 10,
    'right stick': 11,
    'up': 12,
    'down': 13,
    'left': 14,
    'right': 15};
const STICKS = ['left', 'right'];
const AXES = ['x', 'y'];
const DEADZONE = 0.15;
const STORAGE_PREFIX = 'gridwright-saves:';

const str = value => Cast.toString(value);
const num = value => Cast.toNumber(value);

class Scratch3GameBlocks {
    constructor (runtime) {
        this.runtime = runtime;
        this._data = null; // {slot: {key: value}}
        this._slot = '1';
        this._flushTimer = null;
        this._startTime = Date.now();
        this._lastStep = 0;
        this._dt = 1 / 30;
        this._fps = 30;
        this._cursorStyle = null;

        if (this.runtime) {
            this.runtime.on('AFTER_THREADS_STEP', this._onStep.bind(this));
            this.runtime.on('PROJECT_STOP_ALL', () => this._setCursorHidden(false));
        }
        if (typeof window !== 'undefined') {
            window.addEventListener('beforeunload', () => this._flush());
        }
    }

    getInfo () {
        const onOff = {type: ArgumentType.STRING, menu: 'onOff', defaultValue: 'on'};
        return {
            id: 'game',
            name: 'Game',
            blockIconURI,
            menuIconURI: blockIconURI,
            color1: '#7A9A00',
            color2: '#678400',
            color3: '#547000',
            blocks: [
                {
                    opcode: 'saveValue',
                    blockType: BlockType.COMMAND,
                    text: 'save [VALUE] as [KEY]',
                    arguments: {VALUE: {type: ArgumentType.STRING, defaultValue: '10'},
                        KEY: {type: ArgumentType.STRING, defaultValue: 'high score'}}
                },
                {
                    opcode: 'savedValue',
                    blockType: BlockType.REPORTER,
                    text: 'saved [KEY]',
                    arguments: {KEY: {type: ArgumentType.STRING, defaultValue: 'high score'}}
                },
                {
                    opcode: 'hasSaved',
                    blockType: BlockType.BOOLEAN,
                    text: '[KEY] is saved?',
                    arguments: {KEY: {type: ArgumentType.STRING, defaultValue: 'high score'}}
                },
                {
                    opcode: 'deleteSaved',
                    blockType: BlockType.COMMAND,
                    text: 'delete saved [KEY]',
                    arguments: {KEY: {type: ArgumentType.STRING, defaultValue: 'high score'}}
                },
                {opcode: 'deleteAllSaved', blockType: BlockType.COMMAND, text: 'delete everything saved in this slot'},
                {
                    opcode: 'useSlot',
                    blockType: BlockType.COMMAND,
                    text: 'use save slot [SLOT]',
                    arguments: {SLOT: {type: ArgumentType.NUMBER, defaultValue: 1}}
                },
                {opcode: 'currentSlot', blockType: BlockType.REPORTER, text: 'save slot'},
                '---',
                {opcode: 'setFullscreen',
                    blockType: BlockType.COMMAND,
                    text: 'turn fullscreen [ONOFF]',
                    arguments: {ONOFF: onOff}},
                {opcode: 'toggleFullscreen', blockType: BlockType.COMMAND, text: 'toggle fullscreen'},
                {opcode: 'isFullscreen', blockType: BlockType.BOOLEAN, text: 'fullscreen?'},
                {
                    opcode: 'setTitle',
                    blockType: BlockType.COMMAND,
                    text: 'set window title to [TITLE]',
                    arguments: {TITLE: {type: ArgumentType.STRING, defaultValue: 'My game'}}
                },
                {opcode: 'setCursor',
                    blockType: BlockType.COMMAND,
                    text: 'turn mouse pointer [ONOFF]',
                    arguments: {ONOFF: onOff}},
                {opcode: 'quitGame', blockType: BlockType.COMMAND, text: 'quit game'},
                '---',
                {opcode: 'gamepadConnected', blockType: BlockType.BOOLEAN, text: 'gamepad connected?'},
                {
                    opcode: 'gamepadButton',
                    blockType: BlockType.BOOLEAN,
                    text: 'gamepad [BUTTON] pressed?',
                    arguments: {BUTTON: {type: ArgumentType.STRING, menu: 'padButtons', defaultValue: 'A'}}
                },
                {
                    opcode: 'gamepadStick',
                    blockType: BlockType.REPORTER,
                    text: '[STICK] stick [AXIS]',
                    arguments: {
                        STICK: {type: ArgumentType.STRING, menu: 'sticks', defaultValue: 'left'},
                        AXIS: {type: ArgumentType.STRING, menu: 'axes', defaultValue: 'x'}
                    }
                },
                '---',
                {opcode: 'framesPerSecond', blockType: BlockType.REPORTER, text: 'frames per second'},
                {opcode: 'deltaTime', blockType: BlockType.REPORTER, text: 'seconds since last frame'},
                {opcode: 'gameTime', blockType: BlockType.REPORTER, text: 'seconds since the game started'}
            ],
            menus: {
                onOff: {acceptReporters: false, items: ON_OFF},
                padButtons: {acceptReporters: false, items: PAD_BUTTONS},
                sticks: {acceptReporters: false, items: STICKS},
                axes: {acceptReporters: false, items: AXES}
            }
        };
    }

    // ---- saves -----------------------------------------------------------------------------------------------

    _gameId () {
        return (this.runtime.host && this.runtime.host.gameId) || 'editor';
    }

    _load () {
        if (this._data) return this._data;
        let data = null;
        try {
            if (this.runtime.host && this.runtime.host.loadSaves) {
                data = this.runtime.host.loadSaves();
            } else if (typeof window !== 'undefined' && window.localStorage) {
                data = JSON.parse(window.localStorage.getItem(STORAGE_PREFIX + this._gameId()) || 'null');
            }
        } catch (e) {
            data = null;
        }
        this._data = data && typeof data === 'object' ? data : {};
        return this._data;
    }

    _slotData () {
        const data = this._load();
        if (!data[this._slot]) data[this._slot] = {};
        return data[this._slot];
    }

    _scheduleFlush () {
        if (this._flushTimer) return;
        this._flushTimer = setTimeout(() => this._flush(), 150);
    }

    _flush () {
        if (this._flushTimer) {
            clearTimeout(this._flushTimer);
            this._flushTimer = null;
        }
        if (!this._data) return;
        try {
            if (this.runtime.host && this.runtime.host.saveSaves) {
                this.runtime.host.saveSaves(this._data);
            } else if (typeof window !== 'undefined' && window.localStorage) {
                window.localStorage.setItem(STORAGE_PREFIX + this._gameId(), JSON.stringify(this._data));
            }
        } catch (e) {
            // nothing more can be done: the value stays in memory for this session
        }
    }

    saveValue (args) {
        const value = args.VALUE;
        this._slotData()[str(args.KEY)] = typeof value === 'number' || typeof value === 'boolean' ? value : str(value);
        this._scheduleFlush();
    }

    savedValue (args) {
        const slot = this._slotData();
        const key = str(args.KEY);
        return Object.prototype.hasOwnProperty.call(slot, key) ? slot[key] : '';
    }

    hasSaved (args) {
        return Object.prototype.hasOwnProperty.call(this._slotData(), str(args.KEY));
    }

    deleteSaved (args) {
        delete this._slotData()[str(args.KEY)];
        this._scheduleFlush();
    }

    deleteAllSaved () {
        this._load()[this._slot] = {};
        this._scheduleFlush();
    }

    useSlot (args) {
        this._slot = String(Math.max(1, Math.round(num(args.SLOT)) || 1));
    }

    currentSlot () {
        return Number(this._slot);
    }

    // ---- window ----------------------------------------------------------------------------------------------

    _host () {
        return this.runtime.host || {};
    }

    _fullscreenNow () {
        const host = this._host();
        if (host.isFullscreen) return !!host.isFullscreen();
        return typeof document !== 'undefined' && !!document.fullscreenElement;
    }

    _applyFullscreen (on) {
        const host = this._host();
        if (host.setFullscreen) {
            host.setFullscreen(on);
        } else if (typeof document !== 'undefined') {
            if (on && document.documentElement.requestFullscreen) document.documentElement.requestFullscreen();
            if (!on && document.fullscreenElement && document.exitFullscreen) document.exitFullscreen();
        }
    }

    setFullscreen (args) {
        this._applyFullscreen(str(args.ONOFF) !== 'off');
    }

    toggleFullscreen () {
        this._applyFullscreen(!this._fullscreenNow());
    }

    isFullscreen () {
        return this._fullscreenNow();
    }

    setTitle (args) {
        const host = this._host();
        if (host.setTitle) host.setTitle(str(args.TITLE));
        else if (typeof document !== 'undefined') document.title = str(args.TITLE);
    }

    _setCursorHidden (hidden) {
        if (typeof document === 'undefined') return;
        if (hidden && !this._cursorStyle) {
            this._cursorStyle = document.createElement('style');
            this._cursorStyle.textContent = 'html, html * { cursor: none !important; }';
            document.head.appendChild(this._cursorStyle);
        } else if (!hidden && this._cursorStyle) {
            this._cursorStyle.remove();
            this._cursorStyle = null;
        }
    }

    setCursor (args) {
        this._setCursorHidden(str(args.ONOFF) === 'off');
    }

    quitGame () {
        this._flush();
        const host = this._host();
        if (host.quit) host.quit();
        else if (typeof window !== 'undefined') window.close();
    }

    // ---- gamepad ---------------------------------------------------------------------------------------------

    _pad () {
        if (typeof navigator === 'undefined' || !navigator.getGamepads) return null;
        const pads = navigator.getGamepads();
        for (const pad of pads) {
            if (pad && pad.connected) return pad;
        }
        return null;
    }

    gamepadConnected () {
        return !!this._pad();
    }

    gamepadButton (args) {
        const pad = this._pad();
        const index = PAD_INDEX[str(args.BUTTON)];
        if (!pad || typeof index !== 'number' || !pad.buttons[index]) return false;
        return pad.buttons[index].pressed || pad.buttons[index].value > 0.5;
    }

    gamepadStick (args) {
        const pad = this._pad();
        if (!pad) return 0;
        const base = str(args.STICK) === 'right' ? 2 : 0;
        const horizontal = str(args.AXIS) !== 'y';
        let value = pad.axes[base + (horizontal ? 0 : 1)] || 0;
        if (Math.abs(value) < DEADZONE) value = 0;
        // up is positive, like the stage's y axis
        return Math.round((horizontal ? value : -value) * 100);
    }

    // ---- timing ----------------------------------------------------------------------------------------------

    _onStep () {
        const now = performance.now();
        if (this._lastStep) {
            const dt = (now - this._lastStep) / 1000;
            if (dt > 0) {
                this._dt = dt;
                this._fps = (this._fps * 0.9) + ((1 / dt) * 0.1);
            }
        }
        this._lastStep = now;
    }

    framesPerSecond () {
        return Math.round(this._fps);
    }

    deltaTime () {
        return Math.round(this._dt * 1000) / 1000;
    }

    gameTime () {
        return Math.round((Date.now() - this._startTime) / 10) / 100;
    }
}

module.exports = Scratch3GameBlocks;
