import PropTypes from 'prop-types';
import React from 'react';
import classNames from 'classnames';
import {FormattedMessage, defineMessage, useIntl} from 'react-intl';
import UserAvatar from './user-avatar.jsx';

import styles from './author-info.css';

const authorInfo = defineMessage({
    id: 'gui.aria.authorInfo',
    defaultMessage: 'Project "{projectTitle}" by {username}',
    description: 'accessibility label for author info'
});

const AuthorInfo = ({
    className,
    imageUrl,
    projectTitle,
    // TODO: use userId to link to user's profile
    userId,
    username,
    avatarBadge
}) => {
    const intl = useIntl();

    return (<div
        className={classNames(
            className,
            styles.authorInfo
        )}
    >
        <UserAvatar
            className={styles.avatar}
            imageUrl={imageUrl}
            showAvatarBadge={!!avatarBadge}
            wrapperClassName={styles.avatarWrapper}
        />
        <div
            className={styles.titleAuthor}
            aria-label={intl.formatMessage(authorInfo, {
                projectTitle,
                username
            })}
        >
            <span className={styles.projectTitle}>
                {projectTitle}
            </span>
            <div>
                <span className={styles.usernameLine}>
                    <FormattedMessage
                        defaultMessage="by <span>{name}</span>"
                        description="Shows that a project was created by this user"
                        id="gui.authorInfo.byUser"
                        values={{
                            name: username,
                            span: name => (
                                <span className={styles.username}>
                                    {name}
                                </span>
                            )
                        }}
                    />
                </span>
            </div>
        </div>
    </div>);
};

AuthorInfo.propTypes = {
    className: PropTypes.string,
    imageUrl: PropTypes.string,
    projectTitle: PropTypes.string,
    userId: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
    username: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
    avatarBadge: PropTypes.number
};

export default AuthorInfo;
