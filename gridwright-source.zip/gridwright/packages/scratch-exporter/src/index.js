/**
 * Packages a Scratch 3 project (.sb3) into a standalone desktop game.
 *
 * The exported game is the Scratch Desktop app itself running in "player mode": the same VM, renderer and audio
 * engine as the editor, so behaviour matches exactly, but it opens straight into the project with no editor UI.
 * Packaging is done by electron-builder, so a Linux host can produce both an AppImage and a Windows exe.
 */
const os = require('os');
const path = require('path');
const fs = require('fs-extra');
const builder = require('electron-builder');

const {Platform, Arch} = builder;

const DESKTOP_DIR = path.resolve(__dirname, '..', '..', 'scratch-desktop');

/** Export targets: short name -> electron-builder platform and target. */
const TARGETS = {
    linux: {platform: Platform.LINUX, target: 'AppImage', label: 'Linux AppImage'},
    win: {platform: Platform.WINDOWS, target: 'portable', label: 'Windows exe (single file)'}
};

const slugify = name => (
    name.toLowerCase().replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '') || 'scratch-game'
);

/**
 * Copy a package and its runtime dependencies from the monorepo's node_modules into a staging node_modules.
 * @param {string} name - package name
 * @param {string} destModules - destination node_modules directory
 * @param {Set<string>} seen - packages already copied
 * @param {string} fromDir - directory to start module resolution from
 */
const copyRuntimePackage = (name, destModules, seen, fromDir) => {
    if (seen.has(name)) return;
    seen.add(name);
    const pkgJsonPath = require.resolve(`${name}/package.json`, {paths: [fromDir]});
    const pkgDir = path.dirname(pkgJsonPath);
    fs.copySync(pkgDir, path.join(destModules, name), {dereference: true});
    const pkg = fs.readJsonSync(pkgJsonPath);
    for (const dep of Object.keys(pkg.dependencies || {})) {
        copyRuntimePackage(dep, destModules, seen, pkgDir);
    }
};

/**
 * @param {object} options - export options
 * @param {string} options.project - path to the .sb3 file
 * @param {string} [options.name] - game title (defaults to the file name)
 * @param {string[]} [options.targets] - any of 'linux', 'win'
 * @param {string} [options.outDir] - where the finished files go
 * @param {boolean} [options.fullscreen] - start the game fullscreen
 * @param {string} [options.desktopDir] - path to the built scratch-desktop package
 * @param {function(string): void} [options.log] - progress logger
 * @returns {Promise<string[]>} - paths of the files produced
 */
const exportProject = async options => {
    const log = options.log || (() => {});
    const projectPath = path.resolve(options.project);
    if (!await fs.pathExists(projectPath)) {
        throw new Error(`Project file not found: ${projectPath}`);
    }
    const header = (await fs.readFile(projectPath)).subarray(0, 2).toString('latin1');
    if (header !== 'PK') {
        throw new Error(`${projectPath} is not a Scratch 3 project (.sb3 files are zip archives).`);
    }

    const targets = options.targets && options.targets.length ? options.targets : ['linux'];
    for (const t of targets) {
        if (!TARGETS[t]) throw new Error(`Unknown target "${t}". Valid targets: ${Object.keys(TARGETS).join(', ')}`);
    }

    const desktopDir = path.resolve(options.desktopDir || DESKTOP_DIR);
    for (const sub of ['main', 'renderer']) {
        if (!await fs.pathExists(path.join(desktopDir, 'dist', sub, sub === 'main' ? 'main.js' : 'index.html'))) {
            throw new Error(
                `The desktop app has not been built (missing dist/${sub} in ${desktopDir}). ` +
                'Run "npm run build:dist-files" from the repository root first.'
            );
        }
    }

    const name = options.name || path.basename(projectPath, path.extname(projectPath));
    const slug = slugify(name);
    const outDir = path.resolve(options.outDir || 'export-out');
    const electronVersion = fs.readJsonSync(
        require.resolve('electron/package.json', {paths: [desktopDir]})
    ).version;

    const staging = await fs.mkdtemp(path.join(os.tmpdir(), 'scratch-export-'));
    try {
        log(`Staging in ${staging}`);
        await fs.copy(path.join(desktopDir, 'dist', 'main'), path.join(staging, 'dist', 'main'));
        await fs.copy(path.join(desktopDir, 'dist', 'renderer'), path.join(staging, 'dist', 'renderer'));

        await fs.ensureDir(path.join(staging, 'game'));
        await fs.copy(projectPath, path.join(staging, 'game', 'project.sb3'));
        await fs.writeJson(path.join(staging, 'game', 'game.json'), {
            title: name,
            id: slug,
            project: 'project.sb3',
            fullscreen: !!options.fullscreen
        });

        const runtimeDeps = ['source-map-support'];
        const seen = new Set();
        const dependencies = {};
        for (const dep of runtimeDeps) {
            copyRuntimePackage(dep, path.join(staging, 'node_modules'), seen, desktopDir);
            dependencies[dep] = fs.readJsonSync(path.join(staging, 'node_modules', dep, 'package.json')).version;
        }

        await fs.writeJson(path.join(staging, 'package.json'), {
            name: slug,
            productName: name,
            version: '1.0.0',
            description: `${name} (made with Gridwright)`,
            author: name,
            main: './dist/main/main.js',
            dependencies
        }, {spaces: 2});

        const config = {
            appId: `app.gridwright.games.${slug}`,
            productName: name,
            electronVersion,
            directories: {output: outDir},
            files: ['dist/main/**/*', 'dist/renderer/**/*', 'package.json'],
            extraResources: [{from: 'game', to: 'game'}],
            npmRebuild: false,
            nodeGypRebuild: false,
            publish: null,
            linux: {
                target: 'AppImage',
                executableName: slug,
                category: 'Game',
                artifactName: `${slug}-linux-\${arch}.\${ext}`
            },
            win: {
                target: 'portable',
                // Editing the exe's icon/metadata needs Wine on Linux hosts, so it is left off.
                signAndEditExecutable: false,
                artifactName: `${slug}-win-\${arch}.\${ext}`
            }
        };

        const produced = [];
        for (const t of targets) {
            const {platform, target, label} = TARGETS[t];
            log(`Building ${label}...`);
            const results = await builder.build({
                projectDir: staging,
                targets: platform.createTarget(target, Arch.x64),
                // electron-builder modifies the config it is given, so each build gets its own copy
                config: JSON.parse(JSON.stringify(config)),
                publish: 'never'
            });
            produced.push(...results.filter(f => !/\.(blockmap|yml|yaml)$/.test(f)));
        }
        return produced;
    } finally {
        await fs.remove(staging);
    }
};

module.exports = {exportProject, TARGETS, slugify};
