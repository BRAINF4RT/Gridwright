const md5 = require('js-md5');

/**
 * 3D models are stored in the project like costumes and sounds: each frame of a model is a file in the .sb3 zip, and
 * project.json lists the models. In memory they live in runtime.models3d as
 *   [{name, frames: [{name, format: 'obj' | 'glb' | 'gltf', data: Uint8Array, assetId?: string}]}]
 */

const FORMATS = ['obj', 'glb', 'gltf'];

const ensureAssetId = frame => {
    if (!frame.assetId) frame.assetId = md5(frame.data);
    return frame.assetId;
};

/**
 * @param {Runtime} runtime - the runtime holding the models
 * @returns {Array<object>|undefined} the models as listed in project.json (undefined when there are none)
 */
const serializeModels3dJSON = runtime => {
    const models = runtime.models3d || [];
    if (models.length === 0) return;
    return models.map(model => ({
        name: model.name,
        frames: model.frames.map(frame => ({
            name: frame.name,
            assetId: ensureAssetId(frame),
            dataFormat: frame.format,
            md5ext: `${ensureAssetId(frame)}.${frame.format}`
        }))
    }));
};

/**
 * @param {Runtime} runtime - the runtime holding the models
 * @returns {Array<object>} file descriptors ({fileName, fileContent}) for every frame, to add to the project zip
 */
const serializeModels3dFiles = runtime => {
    const files = [];
    for (const model of runtime.models3d || []) {
        for (const frame of model.frames) {
            files.push({fileName: `${ensureAssetId(frame)}.${frame.format}`, fileContent: frame.data});
        }
    }
    return files;
};

/**
 * Load the models listed in a project's JSON from its zip into the runtime.
 * @param {object} json - project.json
 * @param {Runtime} runtime - the runtime to load into
 * @param {JSZip} zip - the project zip (may be missing for JSON-only projects)
 * @returns {Promise} resolves when the models are loaded
 */
const deserializeModels3d = (json, runtime, zip) => {
    const listed = (json && json.models3d) || [];
    if (!zip || listed.length === 0) {
        runtime.models3d = [];
        runtime.requestToolboxExtensionsUpdate();
        return Promise.resolve();
    }
    return Promise.all(listed.map(model => Promise.all((model.frames || []).map(frame => {
        const file = zip.file(frame.md5ext);
        if (!file || !FORMATS.includes(frame.dataFormat)) return null;
        return file.async('uint8array').then(data => ({
            name: frame.name,
            format: frame.dataFormat,
            data,
            assetId: frame.assetId
        }));
    })).then(frames => ({name: model.name, frames: frames.filter(Boolean)}))))
        .then(models => {
            runtime.models3d = models.filter(model => model.frames.length > 0);
            runtime.requestToolboxExtensionsUpdate();
        });
};

module.exports = {serializeModels3dJSON, serializeModels3dFiles, deserializeModels3d, FORMATS};
