/**
 * 3D extension: a Three.js scene that is drawn into the Scratch stage as a layer.
 *
 * The 3D scene renders into its own canvas, and the canvas is copied into a Scratch "canvas skin" shown by a
 * drawable, so it layers correctly with the backdrop and sprites. Rendering only happens when something changed, at
 * an adjustable resolution, so idle scenes cost nothing.
 *
 * Coordinates: x is right, y is up, z points towards the viewer. One unit is one stage pixel; a new shape is 100
 * units across. Angles are in degrees.
 */
const ArgumentType = require('../../extension-support/argument-type');
const BlockType = require('../../extension-support/block-type');
const Cast = require('../../util/cast');
const StageLayering = require('../../engine/stage-layering');
const log = require('../../util/log');
const THREE = require('three');
const {GLTFLoader} = require('three/addons/loaders/GLTFLoader.js');

const iconSvg = '<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40">' +
    '<path d="M20 5 34 12.5v15L20 35 6 27.5v-15z" fill="#fff" stroke="#0E1110" stroke-width="2" ' +
    'stroke-linejoin="round"/><path d="M6 12.5 20 20l14-7.5M20 20v15" fill="none" stroke="#0E1110" ' +
    'stroke-width="2" stroke-linejoin="round"/><path d="M20 5 34 12.5 20 20 6 12.5z" fill="#C4FF0E"/></svg>';
const blockIconURI = `data:image/svg+xml;utf8,${encodeURIComponent(iconSvg)}`;

const SHAPES = ['cube', 'sphere', 'cylinder', 'cone', 'plane', 'torus', 'capsule'];
const MATERIALS = ['matte', 'shiny', 'flat', 'wireframe', 'glowing'];
const LAYERS = ['behind sprites', 'in front of sprites'];
const ON_OFF = ['on', 'off'];
const PROPS = ['x', 'y', 'z', 'rotation x', 'rotation y', 'rotation z', 'size x', 'size y', 'size z'];
const AXES = ['x', 'y', 'z'];
const ANIM_MODES = ['looping', 'once', 'back and forth'];
const EASINGS = ['linear', 'ease in', 'ease out', 'ease in and out', 'bounce'];

const ease = (name, time) => {
    let t = time;
    switch (name) {
    case 'ease in': return t * t;
    case 'ease out': return t * (2 - t);
    case 'ease in and out': return t < 0.5 ? 2 * t * t : -1 + ((4 - (2 * t)) * t);
    case 'bounce':
        if (t < 1 / 2.75) return 7.5625 * t * t;
        if (t < 2 / 2.75) return (7.5625 * (t -= 1.5 / 2.75) * t) + 0.75;
        if (t < 2.5 / 2.75) return (7.5625 * (t -= 2.25 / 2.75) * t) + 0.9375;
        return (7.5625 * (t -= 2.625 / 2.75) * t) + 0.984375;
    default: return t;
    }
};
const DEG = Math.PI / 180;
const BASE_SIZE = 100;

const num = value => Cast.toNumber(value);
const str = value => Cast.toString(value);

/**
 * Parse Wavefront OBJ text into a BufferGeometry (positions, uvs and normals; materials are ignored).
 * @param {string} text - contents of an .obj file
 * @returns {THREE.BufferGeometry} the geometry
 */
const parseOBJ = text => {
    const v = [];
    const vt = [];
    const vn = [];
    const position = [];
    const uv = [];
    const normal = [];
    let hasNormals = true;
    const pushVertex = token => {
        const parts = token.split('/');
        const resolve = (index, list, size) => {
            let i = parseInt(index, 10);
            if (Number.isNaN(i)) return null;
            i = i < 0 ? (list.length / size) + i : i - 1;
            return list.slice(i * size, (i * size) + size);
        };
        const p = resolve(parts[0], v, 3) || [0, 0, 0];
        position.push(p[0], p[1], p[2]);
        const t = parts.length > 1 ? resolve(parts[1], vt, 2) : null;
        uv.push(t ? t[0] : 0, t ? t[1] : 0);
        const n = parts.length > 2 ? resolve(parts[2], vn, 3) : null;
        if (n) {
            normal.push(n[0], n[1], n[2]);
        } else {
            hasNormals = false;
            normal.push(0, 0, 0);
        }
    };
    for (const rawLine of text.split('\n')) {
        const line = rawLine.trim();
        if (!line || line[0] === '#') continue;
        const parts = line.split(/\s+/);
        switch (parts[0]) {
        case 'v': v.push(+parts[1], +parts[2], +parts[3]); break;
        case 'vt': vt.push(+parts[1], +parts[2]); break;
        case 'vn': vn.push(+parts[1], +parts[2], +parts[3]); break;
        case 'f':
            for (let i = 2; i < parts.length - 1; i++) {
                pushVertex(parts[1]);
                pushVertex(parts[i]);
                pushVertex(parts[i + 1]);
            }
            break;
        }
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(position, 3));
    geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    if (hasNormals) {
        geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normal, 3));
    } else {
        geometry.computeVertexNormals();
    }
    return geometry;
};

class Scratch3ThreeDBlocks {
    constructor (runtime) {
        this.runtime = runtime;

        this._ready = false;
        this._failed = false;
        this._objects = new Map();
        this._geometries = new Map();
        this._dirty = false;
        this._quality = 1;
        this._antialias = true;
        this._maxFps = 0;
        this._lastRender = 0;
        this._renderMs = 0;
        this._shadows = false;
        this._layer = 'behind sprites';
        this._visible = true;
        this._gravity = 0;
        this._floor = null;
        this._target = null;
        this._raycaster = null;
        this._frameCache = new Map();
        this._normCache = new Map();
        this._rawCache = new Map();

        if (this.runtime) {
            this.runtime.on('AFTER_THREADS_STEP', this._onStep.bind(this));
            this.runtime.on('STAGE_SIZE_CHANGED', this._onStageSizeChanged.bind(this));
            this.runtime.on('PROJECT_LOADED', () => {
                this._resetScene();
                this._bringToTop();
            });
            // the Stop button stops animations and physics too (objects stay where they are)
            this.runtime.on('PROJECT_STOP_ALL', () => this._stopDynamics());
            this.runtime.on('targetWasCreated', () => {
                if (this._layer !== 'behind sprites') this._bringToTop();
            });
        }
    }

    getInfo () {
        const xyz = (x = 0, y = 0, z = 0) => ({
            X: {type: ArgumentType.NUMBER, defaultValue: x},
            Y: {type: ArgumentType.NUMBER, defaultValue: y},
            Z: {type: ArgumentType.NUMBER, defaultValue: z}
        });
        const name = (defaultValue = 'cube1') => ({type: ArgumentType.STRING, defaultValue});
        const color = defaultValue => ({type: ArgumentType.COLOR, defaultValue});
        const n = defaultValue => ({type: ArgumentType.NUMBER, defaultValue});
        return {
            id: 'threed',
            name: '3D',
            blockIconURI,
            menuIconURI: blockIconURI,
            color1: '#232A28',
            color2: '#1B2120',
            color3: '#101413',
            blocks: [
                {opcode: 'resetScene', blockType: BlockType.COMMAND, text: 'reset 3D scene'},
                {
                    opcode: 'setBackground',
                    blockType: BlockType.COMMAND,
                    text: 'set 3D background to [COLOR]',
                    arguments: {COLOR: color('#87ceeb')}
                },
                {opcode: 'clearBackground', blockType: BlockType.COMMAND, text: 'make 3D background transparent'},
                {
                    opcode: 'setLayer',
                    blockType: BlockType.COMMAND,
                    text: 'put 3D [LAYER]',
                    arguments: {LAYER: {type: ArgumentType.STRING, menu: 'layers', defaultValue: LAYERS[0]}}
                },
                {
                    opcode: 'setDisplay',
                    blockType: BlockType.COMMAND,
                    text: 'turn 3D display [ONOFF]',
                    arguments: {ONOFF: {type: ArgumentType.STRING, menu: 'onOff', defaultValue: 'on'}}
                },
                '---',
                {
                    opcode: 'createObject',
                    blockType: BlockType.COMMAND,
                    text: 'create [SHAPE] named [NAME] at x: [X] y: [Y] z: [Z]',
                    arguments: Object.assign({
                        SHAPE: {type: ArgumentType.STRING, menu: 'shapes', defaultValue: 'cube'},
                        NAME: name()
                    }, xyz())
                },
                {
                    opcode: 'loadModel',
                    blockType: BlockType.COMMAND,
                    text: 'load OBJ model from [URL] named [NAME]',
                    arguments: {URL: {type: ArgumentType.STRING, defaultValue: 'https://example.com/model.obj'},
                        NAME: name('model1')}
                },
                {
                    opcode: 'createModelObject',
                    blockType: BlockType.COMMAND,
                    text: 'create imported model [MODEL] named [NAME] at x: [X] y: [Y] z: [Z]',
                    arguments: Object.assign({
                        MODEL: {type: ArgumentType.STRING, menu: 'models', defaultValue: ' '},
                        NAME: name('model1')
                    }, xyz())
                },
                {
                    opcode: 'switchFrame',
                    blockType: BlockType.COMMAND,
                    text: 'switch [NAME] to frame [FRAME]',
                    arguments: {NAME: name('model1'), FRAME: {type: ArgumentType.STRING, defaultValue: '1'}}
                },
                {opcode: 'nextFrame',
                    blockType: BlockType.COMMAND,
                    text: 'next frame of [NAME]',
                    arguments: {NAME: name('model1')}},
                {opcode: 'previousFrame',
                    blockType: BlockType.COMMAND,
                    text: 'previous frame of [NAME]',
                    arguments: {NAME: name('model1')}},
                {
                    opcode: 'playAnimation',
                    blockType: BlockType.COMMAND,
                    text: 'play [NAME] animation at [FPS] frames per second [MODE]',
                    arguments: {
                        NAME: name('model1'),
                        FPS: n(8),
                        MODE: {type: ArgumentType.STRING, menu: 'animModes', defaultValue: 'looping'}
                    }
                },
                {opcode: 'stopAnimation',
                    blockType: BlockType.COMMAND,
                    text: 'stop [NAME] animation',
                    arguments: {NAME: name('model1')}},
                {
                    opcode: 'duplicateObject',
                    blockType: BlockType.COMMAND,
                    text: 'duplicate [NAME] as [NEWNAME]',
                    arguments: {NAME: name(), NEWNAME: name('cube2')}
                },
                {opcode: 'deleteObject',
                    blockType: BlockType.COMMAND,
                    text: 'delete [NAME]',
                    arguments: {NAME: name()}},
                '---',
                {
                    opcode: 'setPosition',
                    blockType: BlockType.COMMAND,
                    text: 'set [NAME] position to x: [X] y: [Y] z: [Z]',
                    arguments: Object.assign({NAME: name()}, xyz())
                },
                {
                    opcode: 'changePosition',
                    blockType: BlockType.COMMAND,
                    text: 'change [NAME] position by x: [X] y: [Y] z: [Z]',
                    arguments: Object.assign({NAME: name()}, xyz())
                },
                {
                    opcode: 'glideObject',
                    blockType: BlockType.COMMAND,
                    text: 'glide [NAME] to x: [X] y: [Y] z: [Z] in [SECS] seconds [EASING]',
                    arguments: Object.assign({
                        NAME: name(),
                        SECS: n(1),
                        EASING: {type: ArgumentType.STRING, menu: 'easings', defaultValue: 'ease in and out'}
                    }, xyz())
                },
                {
                    opcode: 'setRotation',
                    blockType: BlockType.COMMAND,
                    text: 'set [NAME] rotation to x: [X] y: [Y] z: [Z]',
                    arguments: Object.assign({NAME: name()}, xyz())
                },
                {
                    opcode: 'changeRotation',
                    blockType: BlockType.COMMAND,
                    text: 'turn [NAME] by x: [X] y: [Y] z: [Z] degrees',
                    arguments: Object.assign({NAME: name()}, xyz(0, 1, 0))
                },
                {
                    opcode: 'setSize',
                    blockType: BlockType.COMMAND,
                    text: 'set [NAME] size to x: [X]% y: [Y]% z: [Z]%',
                    arguments: Object.assign({NAME: name()}, xyz(100, 100, 100))
                },
                {
                    opcode: 'setUniformSize',
                    blockType: BlockType.COMMAND,
                    text: 'set [NAME] size to [SIZE]%',
                    arguments: {NAME: name(), SIZE: n(100)}
                },
                {
                    opcode: 'pointAt',
                    blockType: BlockType.COMMAND,
                    text: 'point [NAME] at x: [X] y: [Y] z: [Z]',
                    arguments: Object.assign({NAME: name()}, xyz())
                },
                {
                    opcode: 'moveForward',
                    blockType: BlockType.COMMAND,
                    text: 'move [NAME] [STEPS] steps forward',
                    arguments: {NAME: name(), STEPS: n(10)}
                },
                '---',
                {
                    opcode: 'setColor',
                    blockType: BlockType.COMMAND,
                    text: 'set [NAME] color to [COLOR]',
                    arguments: {NAME: name(), COLOR: color('#ff8c1a')}
                },
                {
                    opcode: 'setMaterial',
                    blockType: BlockType.COMMAND,
                    text: 'set [NAME] material to [MATERIAL]',
                    arguments: {NAME: name(),
                        MATERIAL: {type: ArgumentType.STRING,
                            menu: 'materials',
                            defaultValue: 'matte'}}
                },
                {
                    opcode: 'setOpacity',
                    blockType: BlockType.COMMAND,
                    text: 'set [NAME] opacity to [OPACITY]%',
                    arguments: {NAME: name(), OPACITY: n(100)}
                },
                {
                    opcode: 'setTexture',
                    blockType: BlockType.COMMAND,
                    text: 'set [NAME] texture to costume or image URL [SOURCE]',
                    arguments: {NAME: name(), SOURCE: {type: ArgumentType.STRING, defaultValue: 'costume1'}}
                },
                {opcode: 'showObject',
                    blockType: BlockType.COMMAND,
                    text: 'show [NAME]',
                    arguments: {NAME: name()}},
                {opcode: 'hideObject',
                    blockType: BlockType.COMMAND,
                    text: 'hide [NAME]',
                    arguments: {NAME: name()}},
                '---',
                {
                    opcode: 'setPhysics',
                    blockType: BlockType.COMMAND,
                    text: 'turn physics [ONOFF] for [NAME]',
                    arguments: {ONOFF: {type: ArgumentType.STRING, menu: 'onOff', defaultValue: 'on'},
                        NAME: name()}
                },
                {
                    opcode: 'setVelocity',
                    blockType: BlockType.COMMAND,
                    text: 'set [NAME] velocity to x: [X] y: [Y] z: [Z]',
                    arguments: Object.assign({NAME: name()}, xyz())
                },
                {
                    opcode: 'setBounce',
                    blockType: BlockType.COMMAND,
                    text: 'set [NAME] bounciness to [BOUNCE]%',
                    arguments: {NAME: name(), BOUNCE: n(50)}
                },
                {opcode: 'setGravity',
                    blockType: BlockType.COMMAND,
                    text: 'set gravity to [GRAVITY]',
                    arguments: {GRAVITY: n(600)}},
                {opcode: 'setFloor',
                    blockType: BlockType.COMMAND,
                    text: 'set floor height to [Y]',
                    arguments: {Y: n(-150)}},
                {opcode: 'removeFloor', blockType: BlockType.COMMAND, text: 'remove floor'},
                '---',
                {
                    opcode: 'setCameraPosition',
                    blockType: BlockType.COMMAND,
                    text: 'set camera position to x: [X] y: [Y] z: [Z]',
                    arguments: xyz(0, 0, 400)
                },
                {
                    opcode: 'cameraLookAt',
                    blockType: BlockType.COMMAND,
                    text: 'point camera at x: [X] y: [Y] z: [Z]',
                    arguments: xyz()
                },
                {
                    opcode: 'orbitCamera',
                    blockType: BlockType.COMMAND,
                    text: 'orbit camera around x: [X] y: [Y] z: [Z] distance [DISTANCE] yaw [YAW] pitch [PITCH]',
                    arguments: Object.assign(xyz(), {DISTANCE: n(400), YAW: n(0), PITCH: n(20)})
                },
                {opcode: 'moveCamera',
                    blockType: BlockType.COMMAND,
                    text: 'move camera [STEPS] steps forward',
                    arguments: {STEPS: n(10)}},
                {opcode: 'setFov',
                    blockType: BlockType.COMMAND,
                    text: 'set camera field of view to [FOV]',
                    arguments: {FOV: n(60)}},
                '---',
                {
                    opcode: 'setAmbient',
                    blockType: BlockType.COMMAND,
                    text: 'set ambient light to [COLOR] brightness [BRIGHTNESS]%',
                    arguments: {COLOR: color('#ffffff'), BRIGHTNESS: n(100)}
                },
                {
                    opcode: 'setSun',
                    blockType: BlockType.COMMAND,
                    text: 'set sun direction x: [X] y: [Y] z: [Z] brightness [BRIGHTNESS]%',
                    arguments: Object.assign(xyz(300, 600, 450), {BRIGHTNESS: n(100)})
                },
                {
                    opcode: 'setFog',
                    blockType: BlockType.COMMAND,
                    text: 'set fog color [COLOR] from [NEAR] to [FAR]',
                    arguments: {COLOR: color('#87ceeb'), NEAR: n(400), FAR: n(1500)}
                },
                {opcode: 'clearFog', blockType: BlockType.COMMAND, text: 'turn fog off'},
                {
                    opcode: 'setShadows',
                    blockType: BlockType.COMMAND,
                    text: 'turn shadows [ONOFF]',
                    arguments: {ONOFF: {type: ArgumentType.STRING, menu: 'onOff', defaultValue: 'on'}}
                },
                '---',
                {
                    opcode: 'setQuality',
                    blockType: BlockType.COMMAND,
                    text: 'set 3D render quality to [QUALITY]%',
                    arguments: {QUALITY: n(100)}
                },
                {
                    opcode: 'setAntialias',
                    blockType: BlockType.COMMAND,
                    text: 'turn 3D anti-aliasing [ONOFF]',
                    arguments: {ONOFF: {type: ArgumentType.STRING, menu: 'onOff', defaultValue: 'on'}}
                },
                {
                    opcode: 'setMaxFps',
                    blockType: BlockType.COMMAND,
                    text: 'limit 3D rendering to [FPS] frames per second (0 = no limit)',
                    arguments: {FPS: n(0)}
                },
                '---',
                {
                    opcode: 'objectProp',
                    blockType: BlockType.REPORTER,
                    text: '[PROP] of [NAME]',
                    arguments: {PROP: {type: ArgumentType.STRING, menu: 'props', defaultValue: 'x'}, NAME: name()}
                },
                {
                    opcode: 'distance',
                    blockType: BlockType.REPORTER,
                    text: 'distance between [A] and [B]',
                    arguments: {A: name('cube1'), B: name('cube2')}
                },
                {
                    opcode: 'touching',
                    blockType: BlockType.BOOLEAN,
                    text: '[A] touching [B]?',
                    arguments: {A: name('cube1'), B: name('cube2')}
                },
                {opcode: 'exists',
                    blockType: BlockType.BOOLEAN,
                    text: '[NAME] exists?',
                    arguments: {NAME: name()}},
                {opcode: 'mouseOver',
                    blockType: BlockType.BOOLEAN,
                    text: 'mouse over [NAME]?',
                    arguments: {NAME: name()}},
                {
                    opcode: 'objectAt',
                    blockType: BlockType.REPORTER,
                    text: 'object at stage x: [X] y: [Y]',
                    arguments: {X: n(0), Y: n(0)}
                },
                {opcode: 'objectCount', blockType: BlockType.REPORTER, text: 'number of 3D objects'},
                {
                    opcode: 'cameraProp',
                    blockType: BlockType.REPORTER,
                    text: 'camera [AXIS]',
                    arguments: {AXIS: {type: ArgumentType.STRING, menu: 'axes', defaultValue: 'x'}}
                },
                {opcode: 'frameNumber',
                    blockType: BlockType.REPORTER,
                    text: 'frame number of [NAME]',
                    arguments: {NAME: name('model1')}},
                {opcode: 'frameName',
                    blockType: BlockType.REPORTER,
                    text: 'frame name of [NAME]',
                    arguments: {NAME: name('model1')}},
                {opcode: 'frameCount',
                    blockType: BlockType.REPORTER,
                    text: 'number of frames of [NAME]',
                    arguments: {NAME: name('model1')}},
                {opcode: 'renderTime', blockType: BlockType.REPORTER, text: 'render time for 3D (ms)'}
            ],
            menus: {
                shapes: {acceptReporters: true, items: SHAPES},
                models: {acceptReporters: true, items: '_getModelNames'},
                animModes: {acceptReporters: false, items: ANIM_MODES},
                easings: {acceptReporters: false, items: EASINGS},
                materials: {acceptReporters: true, items: MATERIALS},
                layers: {acceptReporters: false, items: LAYERS},
                onOff: {acceptReporters: false, items: ON_OFF},
                props: {acceptReporters: false, items: PROPS},
                axes: {acceptReporters: false, items: AXES}
            }
        };
    }

    // ---- setup and rendering ---------------------------------------------------------------------------------

    /**
     * Create the Three.js renderer, scene and the Scratch skin/drawable it is shown through.
     * @returns {boolean} true if 3D is available
     */
    _init () {
        if (this._ready) return true;
        if (this._failed) return false;
        const renderer = this.runtime.renderer;
        if (!renderer || typeof renderer.createCanvasSkin !== 'function' || typeof document === 'undefined') {
            this._failed = true;
            return false;
        }
        try {
            this._canvas = document.createElement('canvas');
            this._createGLRenderer();
        } catch (e) {
            log.error('3D: could not start WebGL', e);
            this._failed = true;
            return false;
        }

        this._scene = new THREE.Scene();
        this._camera = new THREE.PerspectiveCamera(60, 4 / 3, 1, 20000);
        this._camera.position.set(0, 0, 400);
        this._target = new THREE.Vector3(0, 0, 0);
        this._camera.lookAt(this._target);
        this._ambient = new THREE.AmbientLight(0xffffff, 1);
        this._sun = new THREE.DirectionalLight(0xffffff, 2);
        this._sun.position.set(300, 600, 450);
        this._scene.add(this._ambient, this._sun);
        this._raycaster = new THREE.Raycaster();

        const W = this.runtime.constructor.STAGE_WIDTH;
        const H = this.runtime.constructor.STAGE_HEIGHT;
        this._skinId = renderer.createCanvasSkin(this._canvas, W, H);
        this._drawableGroup = StageLayering.BACKGROUND_LAYER;
        this._drawableId = renderer.createDrawable(this._drawableGroup);
        renderer.updateDrawableSkinId(this._drawableId, this._skinId);
        this._ready = true;
        this._resize();
        this._applyLayer();
        this._dirty = true;
        return true;
    }

    _createGLRenderer () {
        if (this._gl) this._gl.dispose();
        this._gl = new THREE.WebGLRenderer({
            canvas: this._canvas,
            alpha: true,
            antialias: this._antialias,
            powerPreference: 'high-performance'
        });
        this._gl.setPixelRatio(1);
        this._gl.setClearColor(0x000000, 0);
        this._gl.shadowMap.enabled = this._shadows;
        this._gl.shadowMap.type = THREE.PCFShadowMap;
    }

    _resize () {
        if (!this._ready) return;
        const W = this.runtime.constructor.STAGE_WIDTH;
        const H = this.runtime.constructor.STAGE_HEIGHT;
        this._gl.setSize(Math.max(16, Math.round(W * this._quality)), Math.max(16, Math.round(H * this._quality)),
            false);
        this._camera.aspect = W / H;
        this._camera.updateProjectionMatrix();
        this._dirty = true;
    }

    _onStageSizeChanged () {
        this._resize();
    }

    _applyLayer () {
        const renderer = this.runtime.renderer;
        if (!this._ready || !renderer) return;
        const group = this._layer === 'behind sprites' ? StageLayering.BACKGROUND_LAYER : StageLayering.SPRITE_LAYER;
        if (group !== this._drawableGroup) {
            // a drawable cannot change layer group, so make a new one in the other group
            renderer.destroyDrawable(this._drawableId, this._drawableGroup);
            this._drawableGroup = group;
            this._drawableId = renderer.createDrawable(group);
            renderer.updateDrawableSkinId(this._drawableId, this._skinId);
            renderer.updateDrawableVisible(this._drawableId, this._visible);
        }
        this._bringToTop();
    }

    /**
     * Put the 3D layer above everything else in its layer group. Needed after a project loads (the new backdrop is
     * created after the 3D layer) and, when it is in front of the sprites, whenever a sprite is created.
     */
    _bringToTop () {
        const renderer = this.runtime.renderer;
        if (!this._ready || !renderer) return;
        renderer.setDrawableOrder(this._drawableId, Infinity, this._drawableGroup);
        this.runtime.requestRedraw();
    }

    _stopDynamics () {
        for (const entry of this._objects.values()) {
            if (entry.anim) entry.anim.playing = false;
            entry.velocity.set(0, 0, 0);
        }
    }

    _resetScene () {
        if (!this._ready) return;
        for (const name of Array.from(this._objects.keys())) this._removeObject(name);
        this._scene.fog = null;
        this._gravity = 0;
        this._floor = null;
        this._camera.fov = 60;
        this._camera.position.set(0, 0, 400);
        this._target.set(0, 0, 0);
        this._camera.lookAt(this._target);
        this._camera.updateProjectionMatrix();
        this._ambient.color.set(0xffffff);
        this._ambient.intensity = 1;
        this._sun.color.set(0xffffff);
        this._sun.intensity = 2;
        this._sun.position.set(300, 600, 450);
        this._gl.setClearColor(0x000000, 0);
        this._visible = true;
        this.runtime.renderer.updateDrawableVisible(this._drawableId, true);
        this._dirty = true;
    }

    _onStep () {
        if (!this._ready) return;
        this._stepAnimations(Math.min(0.1, (this.runtime.currentStepTime || 33) / 1000));
        this._stepPhysics();
        if (!this._dirty || !this._visible) return;
        const now = performance.now();
        if (this._maxFps > 0 && now - this._lastRender < 1000 / this._maxFps) return;
        this._lastRender = now;
        this._dirty = false;
        const W = this.runtime.constructor.STAGE_WIDTH;
        const H = this.runtime.constructor.STAGE_HEIGHT;
        this._gl.render(this._scene, this._camera);
        this.runtime.renderer.updateCanvasSkin(this._skinId, this._canvas, W, H);
        this._renderMs = performance.now() - now;
    }

    _stepPhysics () {
        let moving = false;
        const dt = Math.min(0.1, (this.runtime.currentStepTime || 33) / 1000);
        const box = new THREE.Box3();
        for (const entry of this._objects.values()) {
            if (!entry.physics) continue;
            const mesh = entry.mesh;
            entry.velocity.y -= this._gravity * dt;
            if (entry.velocity.lengthSq() === 0) continue;
            mesh.position.addScaledVector(entry.velocity, dt);
            if (this._floor !== null) {
                box.setFromObject(mesh);
                const below = this._floor - box.min.y;
                if (below > 0) {
                    mesh.position.y += below;
                    entry.velocity.y = Math.abs(entry.velocity.y) > 8 ? -entry.velocity.y * entry.bounce : 0;
                    if (entry.velocity.y === 0) {
                        entry.velocity.x *= 0.98;
                        entry.velocity.z *= 0.98;
                    }
                }
            }
            moving = true;
        }
        if (moving) this._dirty = true;
    }

    // ---- objects ---------------------------------------------------------------------------------------------

    _geometry (shape) {
        if (this._geometries.has(shape)) return this._geometries.get(shape);
        let g;
        switch (shape) {
        case 'sphere': g = new THREE.SphereGeometry(BASE_SIZE / 2, 32, 24); break;
        case 'cylinder': g = new THREE.CylinderGeometry(BASE_SIZE / 2, BASE_SIZE / 2, BASE_SIZE, 32); break;
        case 'cone': g = new THREE.ConeGeometry(BASE_SIZE / 2, BASE_SIZE, 32); break;
        case 'plane': g = new THREE.PlaneGeometry(BASE_SIZE, BASE_SIZE); break;
        case 'torus': g = new THREE.TorusGeometry(BASE_SIZE * 0.4, BASE_SIZE * 0.15, 16, 48); break;
        case 'capsule': g = new THREE.CapsuleGeometry(BASE_SIZE * 0.3, BASE_SIZE * 0.4, 8, 16); break;
        default: g = new THREE.BoxGeometry(BASE_SIZE, BASE_SIZE, BASE_SIZE);
        }
        this._geometries.set(shape, g);
        return g;
    }

    _makeMaterial (entry) {
        const color = entry.color;
        let material;
        switch (entry.style) {
        case 'shiny': material = new THREE.MeshStandardMaterial({color, roughness: 0.25, metalness: 0.4}); break;
        case 'flat': material = new THREE.MeshBasicMaterial({color}); break;
        case 'wireframe': material = new THREE.MeshBasicMaterial({color, wireframe: true}); break;
        case 'glowing':
            material = new THREE.MeshStandardMaterial({color, emissive: color, emissiveIntensity: 0.8});
            break;
        default: material = new THREE.MeshStandardMaterial({color, roughness: 1, metalness: 0});
        }
        material.side = THREE.DoubleSide;
        material.transparent = entry.opacity < 1;
        material.opacity = entry.opacity;
        if (entry.map) material.map = entry.map;
        return material;
    }

    _applyMaterial (entry) {
        if (entry.imported) {
            // imported models keep their own materials until a colour, material, opacity or texture is set
            if (entry.override) {
                if (entry.sharedMaterial) entry.sharedMaterial.dispose();
                entry.sharedMaterial = null;
                this._assignOverride(entry);
            }
            this._applyShadowFlags(entry.mesh);
            this._dirty = true;
            return;
        }
        const old = entry.mesh.material;
        entry.mesh.traverse(child => {
            if (child.isMesh) child.material = this._makeMaterial(entry);
        });
        if (old && old.dispose) old.dispose();
        this._applyShadowFlags(entry.mesh);
        this._dirty = true;
    }

    _applyShadowFlags (object) {
        object.traverse(child => {
            if (child.isMesh) {
                child.castShadow = this._shadows;
                child.receiveShadow = this._shadows;
            }
        });
    }

    _addEntry (name, mesh, extra) {
        if (this._objects.has(name)) this._removeObject(name);
        mesh.userData.name = name;
        const entry = Object.assign({
            mesh,
            color: new THREE.Color(0xff8c1a),
            style: 'matte',
            opacity: 1,
            map: null,
            physics: false,
            velocity: new THREE.Vector3(),
            bounce: 0.5
        }, extra);
        this._objects.set(name, entry);
        this._scene.add(mesh);
        this._applyMaterial(entry);
        return entry;
    }

    _removeObject (name) {
        const entry = this._objects.get(name);
        if (!entry) return;
        this._scene.remove(entry.mesh);
        if (!entry.imported) {
            entry.mesh.traverse(child => {
                if (child.isMesh && child.material) child.material.dispose();
            });
        } else if (entry.sharedMaterial) {
            entry.sharedMaterial.dispose();
        }
        if (entry.ownsGeometry) entry.mesh.geometry.dispose();
        if (entry.map) entry.map.dispose();
        this._objects.delete(name);
        this._dirty = true;
    }

    _get (name) {
        if (!this._init()) return null;
        return this._objects.get(str(name)) || null;
    }

    _rayHit (x, y) {
        if (!this._init()) return null;
        const W = this.runtime.constructor.STAGE_WIDTH;
        const H = this.runtime.constructor.STAGE_HEIGHT;
        this._camera.updateMatrixWorld();
        this._raycaster.setFromCamera({x: x / (W / 2), y: y / (H / 2)}, this._camera);
        const meshes = [];
        for (const entry of this._objects.values()) {
            if (entry.mesh.visible) meshes.push(entry.mesh);
        }
        const hits = this._raycaster.intersectObjects(meshes, true);
        if (hits.length === 0) return null;
        let node = hits[0].object;
        while (node && !node.userData.name) node = node.parent;
        return node ? node.userData.name : null;
    }

    // ---- scene blocks ----------------------------------------------------------------------------------------

    resetScene () {
        if (this._init()) this._resetScene();
    }

    setBackground (args) {
        if (!this._init()) return;
        this._gl.setClearColor(new THREE.Color(str(args.COLOR)), 1);
        this._dirty = true;
    }

    clearBackground () {
        if (!this._init()) return;
        this._gl.setClearColor(0x000000, 0);
        this._dirty = true;
    }

    setLayer (args) {
        this._layer = LAYERS.includes(str(args.LAYER)) ? str(args.LAYER) : LAYERS[0];
        this._applyLayer();
    }

    setDisplay (args) {
        if (!this._init()) return;
        this._visible = str(args.ONOFF) !== 'off';
        this.runtime.renderer.updateDrawableVisible(this._drawableId, this._visible);
        this._dirty = true;
        this.runtime.requestRedraw();
    }

    setAmbient (args) {
        if (!this._init()) return;
        this._ambient.color.set(str(args.COLOR));
        this._ambient.intensity = Math.max(0, num(args.BRIGHTNESS) / 100);
        this._dirty = true;
    }

    setSun (args) {
        if (!this._init()) return;
        this._sun.position.set(num(args.X), num(args.Y), num(args.Z));
        this._sun.intensity = Math.max(0, num(args.BRIGHTNESS) / 50);
        this._dirty = true;
    }

    setFog (args) {
        if (!this._init()) return;
        this._scene.fog = new THREE.Fog(new THREE.Color(str(args.COLOR)), num(args.NEAR), num(args.FAR));
        this._dirty = true;
    }

    clearFog () {
        if (!this._init()) return;
        this._scene.fog = null;
        this._dirty = true;
    }

    setShadows (args) {
        if (!this._init()) return;
        this._shadows = str(args.ONOFF) !== 'off';
        this._gl.shadowMap.enabled = this._shadows;
        this._sun.castShadow = this._shadows;
        if (this._shadows) {
            const s = this._sun.shadow;
            s.mapSize.set(1024, 1024);
            s.camera.left = -600;
            s.camera.right = 600;
            s.camera.top = 600;
            s.camera.bottom = -600;
            s.camera.near = 10;
            s.camera.far = 3000;
        }
        for (const entry of this._objects.values()) {
            this._applyShadowFlags(entry.mesh);
            entry.mesh.traverse(child => {
                if (child.isMesh) child.material.needsUpdate = true;
            });
        }
        this._dirty = true;
    }

    // ---- object blocks ---------------------------------------------------------------------------------------

    createObject (args) {
        if (!this._init()) return;
        const shape = SHAPES.includes(str(args.SHAPE)) ? str(args.SHAPE) : 'cube';
        const mesh = new THREE.Mesh(this._geometry(shape));
        mesh.position.set(num(args.X), num(args.Y), num(args.Z));
        this._addEntry(str(args.NAME), mesh);
    }

    loadModel (args) {
        if (!this._init()) return Promise.resolve();
        const url = str(args.URL);
        const name = str(args.NAME);
        const ext = (url.split(/[?#]/)[0].split('.')
            .pop() || '').toLowerCase();
        const format = ['glb', 'gltf'].includes(ext) ? ext : 'obj';
        return fetch(url)
            .then(response => {
                if (!response.ok) throw new Error(`HTTP ${response.status}`);
                return response.arrayBuffer();
            })
            .then(buffer => {
                const model = {
                    name: `url:${url}`,
                    rev: 0,
                    frames: [{name: name, format, data: new Uint8Array(buffer)}]
                };
                return this._instantiateModel(model, name, [0, 0, 0]);
            })
            .catch(e => log.warn('3D: could not load model', url, e));
    }

    // ---- imported models and their frames (stop-motion animation) --------------------------------------------

    _getModelNames () {
        const names = (this.runtime.models3d || []).map(model => model.name);
        return names.length > 0 ? names : [' '];
    }

    _findModel (name) {
        return (this.runtime.models3d || []).find(model => model.name === name) || null;
    }

    _modelKey (model) {
        return `${model.name}|${model.rev || 0}|${model.frames.length}|${model.frames[0].assetId || ''}`;
    }

    _parseFrame (model, index) {
        const key = `${this._modelKey(model)}|${index}`;
        if (this._rawCache.has(key)) return this._rawCache.get(key);
        const frame = model.frames[index];
        const promise = new Promise((resolve, reject) => {
            if (frame.format === 'obj') {
                const geometry = parseOBJ(new TextDecoder().decode(frame.data));
                const material = new THREE.MeshStandardMaterial({color: 0xd0d0d0, roughness: 0.8, metalness: 0});
                material.side = THREE.DoubleSide;
                resolve(new THREE.Mesh(geometry, material));
            } else {
                const bytes = frame.data;
                const buffer = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
                new GLTFLoader().parse(buffer, '', gltf => resolve(gltf.scene), reject);
            }
        });
        this._rawCache.set(key, promise);
        return promise;
    }

    /**
     * Every frame of a model is centred and scaled the same way, using the first frame, so that frames line up and a
     * model is 100 units across like the built-in shapes.
     * @param {object} model - the imported model
     * @returns {Promise<{scale: number, center: THREE.Vector3}>} the shared normalisation
     */
    _getNorm (model) {
        const key = this._modelKey(model);
        if (this._normCache.has(key)) return this._normCache.get(key);
        const promise = this._parseFrame(model, 0).then(raw => {
            const box = new THREE.Box3().setFromObject(raw);
            const size = new THREE.Vector3();
            const center = new THREE.Vector3();
            box.getSize(size);
            box.getCenter(center);
            const longest = Math.max(size.x, size.y, size.z);
            return {scale: longest > 0 ? BASE_SIZE / longest : 1, center};
        });
        this._normCache.set(key, promise);
        return promise;
    }

    _loadFrame (model, index) {
        const key = `${this._modelKey(model)}|${index}`;
        if (this._frameCache.has(key)) return this._frameCache.get(key);
        const promise = Promise.all([this._parseFrame(model, index), this._getNorm(model)]).then(([raw, norm]) => {
            const inner = new THREE.Group();
            inner.add(raw);
            raw.position.set(-norm.center.x, -norm.center.y, -norm.center.z);
            const holder = new THREE.Group();
            holder.add(inner);
            holder.scale.setScalar(norm.scale);
            return holder;
        });
        this._frameCache.set(key, promise);
        return promise;
    }

    /**
     * Create a scene object from an imported model, with every frame loaded and ready to switch to.
     * @param {object} model - the imported model
     * @param {string} name - name for the new object
     * @param {Array<number>} position - x, y, z
     * @returns {Promise} resolves when the object exists
     */
    _instantiateModel (model, name, position) {
        return Promise.all(model.frames.map((frame, i) => this._loadFrame(model, i))).then(templates => {
            if (!this._ready) return;
            const group = new THREE.Group();
            group.position.set(position[0], position[1], position[2]);
            const entry = this._addEntry(name, group, {
                imported: true, model, templates, frameIndex: 0, cloneCache: [], override: false, anim: null
            });
            this._showFrame(entry, 0);
            return entry;
        });
    }

    _showFrame (entry, index) {
        const count = entry.templates.length;
        const i = ((Math.round(index) % count) + count) % count;
        let instance = entry.cloneCache[i];
        if (!instance) {
            instance = entry.templates[i].clone(true);
            entry.cloneCache[i] = instance;
        }
        entry.mesh.clear();
        entry.mesh.add(instance);
        entry.frameIndex = i;
        if (entry.override) this._assignOverride(entry);
        this._applyShadowFlags(entry.mesh);
        this._dirty = true;
    }

    _assignOverride (entry) {
        if (!entry.sharedMaterial) entry.sharedMaterial = this._makeMaterial(entry);
        entry.mesh.traverse(child => {
            if (child.isMesh) child.material = entry.sharedMaterial;
        });
    }

    _frameIndexFor (entry, value) {
        const text = str(value).trim();
        const count = entry.templates.length;
        if (text !== '' && !Number.isNaN(Number(text))) {
            return (((Math.round(Number(text)) - 1) % count) + count) % count;
        }
        const byName = entry.model.frames.findIndex(frame => frame.name.toLowerCase() === text.toLowerCase());
        return byName;
    }

    _stepAnimations (dt) {
        for (const entry of this._objects.values()) {
            const anim = entry.anim;
            if (!entry.imported || !anim || !anim.playing) continue;
            anim.time += dt;
            const count = entry.templates.length;
            const step = Math.floor(anim.time * anim.fps);
            let index;
            if (anim.mode === 'once') {
                index = Math.min(step, count - 1);
                if (step >= count - 1) anim.playing = false;
            } else if (anim.mode === 'back and forth' && count > 1) {
                const cycle = (count - 1) * 2;
                const pos = step % cycle;
                index = pos < count ? pos : cycle - pos;
            } else {
                index = step % count;
            }
            if (index !== entry.frameIndex) this._showFrame(entry, index);
        }
    }

    createModelObject (args) {
        if (!this._init()) return Promise.resolve();
        const model = this._findModel(str(args.MODEL));
        if (!model || model.frames.length === 0) return Promise.resolve();
        return this._instantiateModel(model, str(args.NAME), [num(args.X), num(args.Y), num(args.Z)])
            .catch(e => log.warn('3D: could not create model', e));
    }

    switchFrame (args) {
        const e = this._get(args.NAME);
        if (!e || !e.imported) return;
        const index = this._frameIndexFor(e, args.FRAME);
        if (index >= 0) this._showFrame(e, index);
    }

    nextFrame (args) {
        const e = this._get(args.NAME);
        if (e && e.imported) this._showFrame(e, e.frameIndex + 1);
    }

    previousFrame (args) {
        const e = this._get(args.NAME);
        if (e && e.imported) this._showFrame(e, e.frameIndex - 1);
    }

    playAnimation (args) {
        const e = this._get(args.NAME);
        if (!e || !e.imported) return;
        const mode = ANIM_MODES.includes(str(args.MODE)) ? str(args.MODE) : 'looping';
        e.anim = {playing: true, fps: Math.max(0.1, num(args.FPS)), mode, time: 0};
        this._showFrame(e, 0);
    }

    stopAnimation (args) {
        const e = this._get(args.NAME);
        if (e && e.anim) e.anim.playing = false;
    }

    frameNumber (args) {
        const e = this._get(args.NAME);
        return e && e.imported ? e.frameIndex + 1 : 0;
    }

    frameName (args) {
        const e = this._get(args.NAME);
        return e && e.imported ? e.model.frames[e.frameIndex].name : '';
    }

    frameCount (args) {
        const e = this._get(args.NAME);
        return e && e.imported ? e.templates.length : 0;
    }

    duplicateObject (args) {
        const source = this._get(args.NAME);
        if (!source) return;
        if (source.imported) {
            this._instantiateModel(source.model, str(args.NEWNAME), source.mesh.position.toArray()).then(entry => {
                if (!entry) return;
                entry.mesh.rotation.copy(source.mesh.rotation);
                entry.mesh.scale.copy(source.mesh.scale);
                this._showFrame(entry, source.frameIndex);
            });
            return;
        }
        const mesh = source.mesh.clone();
        const entry = this._addEntry(str(args.NEWNAME), mesh, {
            color: source.color.clone(),
            style: source.style,
            opacity: source.opacity,
            map: source.map,
            bounce: source.bounce,
            physics: source.physics
        });
        entry.velocity.copy(source.velocity);
        this._applyMaterial(entry);
    }

    deleteObject (args) {
        if (this._init()) this._removeObject(str(args.NAME));
    }

    setPosition (args) {
        const e = this._get(args.NAME);
        if (!e) return;
        e.mesh.position.set(num(args.X), num(args.Y), num(args.Z));
        this._dirty = true;
    }

    glideObject (args, util) {
        const e = this._get(args.NAME);
        if (!e) return;
        const frame = util.stackFrame;
        if (!frame.started) {
            frame.started = Date.now();
            frame.from = e.mesh.position.clone();
            frame.to = new THREE.Vector3(num(args.X), num(args.Y), num(args.Z));
            frame.duration = Math.max(0, num(args.SECS)) * 1000;
            if (frame.duration === 0) {
                e.mesh.position.copy(frame.to);
                this._dirty = true;
                return;
            }
            util.yield();
            return;
        }
        const t = Math.min(1, (Date.now() - frame.started) / frame.duration);
        e.mesh.position.copy(frame.from).lerp(frame.to, ease(str(args.EASING), t));
        this._dirty = true;
        if (t < 1) util.yield();
    }

    changePosition (args) {
        const e = this._get(args.NAME);
        if (!e) return;
        e.mesh.position.add(new THREE.Vector3(num(args.X), num(args.Y), num(args.Z)));
        this._dirty = true;
    }

    setRotation (args) {
        const e = this._get(args.NAME);
        if (!e) return;
        e.mesh.rotation.set(num(args.X) * DEG, num(args.Y) * DEG, num(args.Z) * DEG);
        this._dirty = true;
    }

    changeRotation (args) {
        const e = this._get(args.NAME);
        if (!e) return;
        e.mesh.rotation.x += num(args.X) * DEG;
        e.mesh.rotation.y += num(args.Y) * DEG;
        e.mesh.rotation.z += num(args.Z) * DEG;
        this._dirty = true;
    }

    setSize (args) {
        const e = this._get(args.NAME);
        if (!e) return;
        e.mesh.scale.set(num(args.X) / 100, num(args.Y) / 100, num(args.Z) / 100);
        this._dirty = true;
    }

    setUniformSize (args) {
        const e = this._get(args.NAME);
        if (!e) return;
        const s = num(args.SIZE) / 100;
        e.mesh.scale.set(s, s, s);
        this._dirty = true;
    }

    pointAt (args) {
        const e = this._get(args.NAME);
        if (!e) return;
        e.mesh.lookAt(num(args.X), num(args.Y), num(args.Z));
        this._dirty = true;
    }

    moveForward (args) {
        const e = this._get(args.NAME);
        if (!e) return;
        e.mesh.translateZ(num(args.STEPS));
        this._dirty = true;
    }

    setColor (args) {
        const e = this._get(args.NAME);
        if (!e) return;
        e.color = new THREE.Color(str(args.COLOR));
        e.override = true;
        this._applyMaterial(e);
    }

    setMaterial (args) {
        const e = this._get(args.NAME);
        if (!e) return;
        e.style = MATERIALS.includes(str(args.MATERIAL)) ? str(args.MATERIAL) : 'matte';
        e.override = true;
        this._applyMaterial(e);
    }

    setOpacity (args) {
        const e = this._get(args.NAME);
        if (!e) return;
        e.opacity = Math.max(0, Math.min(1, num(args.OPACITY) / 100));
        e.override = true;
        this._applyMaterial(e);
    }

    setTexture (args, util) {
        const e = this._get(args.NAME);
        if (!e) return Promise.resolve();
        const source = str(args.SOURCE);
        let url = source;
        if (!/^(https?:|data:|file:|blob:)/.test(source)) {
            const costume = util.target.getCostumes().find(c => c.name === source);
            if (!costume || !costume.asset) return Promise.resolve();
            url = costume.asset.encodeDataURI();
        }
        return new Promise(resolve => {
            new THREE.TextureLoader().load(url, texture => {
                texture.colorSpace = THREE.SRGBColorSpace;
                if (e.map) e.map.dispose();
                e.map = texture;
                e.override = true;
                this._applyMaterial(e);
                resolve();
            }, null, () => {
                log.warn('3D: could not load texture', source.slice(0, 60));
                resolve();
            });
        });
    }

    showObject (args) {
        const e = this._get(args.NAME);
        if (!e) return;
        e.mesh.visible = true;
        this._dirty = true;
    }

    hideObject (args) {
        const e = this._get(args.NAME);
        if (!e) return;
        e.mesh.visible = false;
        this._dirty = true;
    }

    // ---- physics ---------------------------------------------------------------------------------------------

    setPhysics (args) {
        const e = this._get(args.NAME);
        if (e) e.physics = str(args.ONOFF) !== 'off';
    }

    setVelocity (args) {
        const e = this._get(args.NAME);
        if (e) e.velocity.set(num(args.X), num(args.Y), num(args.Z));
    }

    setBounce (args) {
        const e = this._get(args.NAME);
        if (e) e.bounce = Math.max(0, Math.min(1, num(args.BOUNCE) / 100));
    }

    setGravity (args) {
        this._gravity = num(args.GRAVITY);
    }

    setFloor (args) {
        this._floor = num(args.Y);
    }

    removeFloor () {
        this._floor = null;
    }

    // ---- camera ----------------------------------------------------------------------------------------------

    _updateCamera () {
        this._camera.lookAt(this._target);
        this._dirty = true;
    }

    setCameraPosition (args) {
        if (!this._init()) return;
        this._camera.position.set(num(args.X), num(args.Y), num(args.Z));
        this._updateCamera();
    }

    cameraLookAt (args) {
        if (!this._init()) return;
        this._target.set(num(args.X), num(args.Y), num(args.Z));
        this._updateCamera();
    }

    orbitCamera (args) {
        if (!this._init()) return;
        this._target.set(num(args.X), num(args.Y), num(args.Z));
        const yaw = num(args.YAW) * DEG;
        const pitch = Math.max(-89, Math.min(89, num(args.PITCH))) * DEG;
        const d = Math.max(1, num(args.DISTANCE));
        this._camera.position.set(
            this._target.x + (d * Math.cos(pitch) * Math.sin(yaw)),
            this._target.y + (d * Math.sin(pitch)),
            this._target.z + (d * Math.cos(pitch) * Math.cos(yaw))
        );
        this._updateCamera();
    }

    moveCamera (args) {
        if (!this._init()) return;
        const dir = this._target.clone().sub(this._camera.position)
            .normalize()
            .multiplyScalar(num(args.STEPS));
        this._camera.position.add(dir);
        this._target.add(dir);
        this._updateCamera();
    }

    setFov (args) {
        if (!this._init()) return;
        this._camera.fov = Math.max(5, Math.min(170, num(args.FOV)));
        this._camera.updateProjectionMatrix();
        this._dirty = true;
    }

    // ---- performance -----------------------------------------------------------------------------------------

    setQuality (args) {
        this._quality = Math.max(0.1, Math.min(2, num(args.QUALITY) / 100));
        this._resize();
    }

    setAntialias (args) {
        this._antialias = str(args.ONOFF) !== 'off';
        if (!this._init()) return;
        // anti-aliasing is fixed when the WebGL context is created, so it has to be recreated
        const clear = new THREE.Color();
        this._gl.getClearColor(clear);
        const alpha = this._gl.getClearAlpha();
        this._createGLRenderer();
        this._gl.setClearColor(clear, alpha);
        this._resize();
    }

    setMaxFps (args) {
        this._maxFps = Math.max(0, num(args.FPS));
    }

    // ---- reporters -------------------------------------------------------------------------------------------

    objectProp (args) {
        const e = this._get(args.NAME);
        if (!e) return 0;
        const m = e.mesh;
        const round = value => Math.round(value * 1000) / 1000;
        switch (str(args.PROP)) {
        case 'x': return round(m.position.x);
        case 'y': return round(m.position.y);
        case 'z': return round(m.position.z);
        case 'rotation x': return round(m.rotation.x / DEG);
        case 'rotation y': return round(m.rotation.y / DEG);
        case 'rotation z': return round(m.rotation.z / DEG);
        case 'size x': return round(m.scale.x * 100);
        case 'size y': return round(m.scale.y * 100);
        case 'size z': return round(m.scale.z * 100);
        }
        return 0;
    }

    distance (args) {
        const a = this._get(args.A);
        const b = this._get(args.B);
        if (!a || !b) return 0;
        return Math.round(a.mesh.position.distanceTo(b.mesh.position) * 1000) / 1000;
    }

    touching (args) {
        const a = this._get(args.A);
        const b = this._get(args.B);
        if (!a || !b) return false;
        return new THREE.Box3().setFromObject(a.mesh)
            .intersectsBox(new THREE.Box3().setFromObject(b.mesh));
    }

    exists (args) {
        return this._init() && this._objects.has(str(args.NAME));
    }

    mouseOver (args) {
        const mouse = this.runtime.ioDevices.mouse;
        return this._rayHit(mouse.getScratchX(), mouse.getScratchY()) === str(args.NAME);
    }

    objectAt (args) {
        return this._rayHit(num(args.X), num(args.Y)) || '';
    }

    objectCount () {
        return this._objects.size;
    }

    cameraProp (args) {
        if (!this._init()) return 0;
        const axis = str(args.AXIS);
        return Math.round((this._camera.position[axis] || 0) * 1000) / 1000;
    }

    renderTime () {
        return Math.round(this._renderMs * 100) / 100;
    }
}

module.exports = Scratch3ThreeDBlocks;
