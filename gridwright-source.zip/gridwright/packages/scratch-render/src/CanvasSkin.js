const twgl = require('twgl.js');

const Skin = require('./Skin');

/**
 * A skin whose texture is a copy of an HTML canvas, for example a canvas that another WebGL context (such as a 3D
 * engine) renders into. The canvas is uploaded straight to the GPU texture with no CPU read back, and the skin is
 * not collidable: it never reports touching anything.
 */
class CanvasSkin extends Skin {
    /**
     * @param {int} id - The ID for this Skin.
     * @param {RenderWebGL} renderer - The renderer which will use this skin.
     */
    constructor (id, renderer) {
        super(id);
        this._renderer = renderer;
        const gl = renderer.gl;
        this._size = [1, 1];
        // An empty silhouette, so nothing ever touches this skin. This clears this._texture, so it has to come first.
        this.setEmptyImageData();
        this._texture = twgl.createTexture(gl, {auto: false, wrap: gl.CLAMP_TO_EDGE, min: gl.LINEAR, mag: gl.LINEAR});
    }

    dispose () {
        if (this._texture) {
            this._renderer.gl.deleteTexture(this._texture);
            this._texture = null;
        }
        super.dispose();
    }

    /**
     * @returns {Array<number>} the size of this skin in stage units.
     */
    get size () {
        return this._size;
    }

    getTexture () {
        return this._texture || super.getTexture();
    }

    /**
     * Copy the current contents of a canvas into this skin.
     * @param {HTMLCanvasElement} canvas - the canvas to copy from.
     * @param {number} width - the width this skin should cover, in stage units.
     * @param {number} height - the height this skin should cover, in stage units.
     */
    setCanvas (canvas, width, height) {
        const gl = this._renderer.gl;
        gl.bindTexture(gl.TEXTURE_2D, this._texture);
        // Scratch's shaders expect premultiplied alpha
        gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, canvas);
        gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
        this._size = [width, height];
        this._rotationCenter[0] = width / 2;
        this._rotationCenter[1] = height / 2;
        this.emit(Skin.Events.WasAltered);
    }
}

module.exports = CanvasSkin;
