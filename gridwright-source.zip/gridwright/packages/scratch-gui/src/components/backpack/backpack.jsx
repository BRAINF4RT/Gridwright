import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {FormattedMessage, defineMessages, useIntl} from 'react-intl';
import DragConstants from '../../lib/drag-constants';
import {ComingSoonTooltip} from '../coming-soon/coming-soon.jsx';
import SpriteSelectorItem from '../../containers/sprite-selector-item.jsx';
import styles from './backpack.css';

// TODO make sprite selector item not require onClick
const noop = () => {};

const dragTypeMap = { // Keys correspond with the backpack-server item types
    costume: DragConstants.BACKPACK_COSTUME,
    sound: DragConstants.BACKPACK_SOUND,
    script: DragConstants.BACKPACK_CODE,
    sprite: DragConstants.BACKPACK_SPRITE
};

const labelMap = defineMessages({
    costume: {
        id: 'gui.backpack.costumeLabel',
        defaultMessage: 'costume',
        description: 'Label for costume backpack item'
    },
    sound: {
        id: 'gui.backpack.soundLabel',
        defaultMessage: 'sound',
        description: 'Label for sound backpack item'
    },
    script: {
        id: 'gui.backpack.scriptLabel',
        defaultMessage: 'script',
        description: 'Label for script backpack item'
    },
    sprite: {
        id: 'gui.backpack.spriteLabel',
        defaultMessage: 'sprite',
        description: 'Label for sprite backpack item'
    }
});

const Backpack = ({
    ariaLabel,
    ariaRole,
    blockDragOver,
    containerRef,
    contents,
    dragOver,
    error,
    expanded,
    loading,
    showMore,
    onToggle,
    onDelete,
    onMore,
    onPointerEnter,
    onPointerLeave
}) => {
    const intl = useIntl();
    return (
        <section
            className={styles.backpackContainer}
            role={ariaRole}
            aria-label={ariaLabel}
        >
            <div
                className={styles.backpackHeader}
                onClick={onToggle}
            >
                {onToggle ? (
                    <FormattedMessage
                        defaultMessage="Backpack"
                        description="Button to open the backpack"
                        id="gui.backpack.header"
                    />
                ) : (
                    <ComingSoonTooltip
                        place="top"
                        tooltipId="backpack-tooltip"
                    >
                        <FormattedMessage
                            defaultMessage="Backpack"
                            description="Button to open the backpack"
                            id="gui.backpack.header"
                        />
                    </ComingSoonTooltip>
                )}
            </div>
            {expanded ? (
                <div
                    className={classNames(styles.backpackList, {
                        [styles.dragOver]: dragOver || blockDragOver
                    })}
                    ref={containerRef}
                    onPointerEnter={onPointerEnter}
                    onPointerLeave={onPointerLeave}
                >
                    {error ? (
                        <div className={styles.statusMessage}>
                            <FormattedMessage
                                defaultMessage="Error loading backpack"
                                description="Error backpack message"
                                id="gui.backpack.errorBackpack"
                            />
                        </div>
                    ) : (
                        loading ? (
                            <div className={styles.statusMessage}>
                                <FormattedMessage
                                    defaultMessage="Loading..."
                                    description="Loading backpack message"
                                    id="gui.backpack.loadingBackpack"
                                />
                            </div>
                        ) : (
                            contents.length > 0 ? (
                                <ul className={styles.backpackListInner}>
                                    {contents.map(item => (
                                        <li key={item.id}>
                                            <SpriteSelectorItem
                                                className={styles.backpackItem}
                                                costumeURL={item.thumbnailUrl}
                                                details={item.name}
                                                dragPayload={item}
                                                dragType={dragTypeMap[item.type]}
                                                id={item.id}
                                                name={intl.formatMessage(labelMap[item.type])}
                                                selected={false}
                                                onClick={noop}
                                                onDeleteButtonClick={onDelete}
                                            />
                                        </li>
                                    ))}
                                    {showMore && (
                                        <li>
                                            <button
                                                className={styles.more}
                                                onClick={onMore}
                                            >
                                                <FormattedMessage
                                                    defaultMessage="More"
                                                    description="Load more from backpack"
                                                    id="gui.backpack.more"
                                                />
                                            </button>
                                        </li>
                                    )}
                                </ul>
                            ) : (
                                <div className={styles.statusMessage}>
                                    <FormattedMessage
                                        defaultMessage="Backpack is empty"
                                        description="Empty backpack message"
                                        id="gui.backpack.emptyBackpack"
                                    />
                                </div>
                            )
                        )
                    )}
                </div>
            ) : null}
        </section>
    );
};

Backpack.propTypes = {
    ariaLabel: PropTypes.string,
    ariaRole: PropTypes.string,
    blockDragOver: PropTypes.bool,
    containerRef: PropTypes.func,
    contents: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.string,
        thumbnailUrl: PropTypes.string,
        type: PropTypes.string,
        name: PropTypes.string
    })),
    dragOver: PropTypes.bool,
    error: PropTypes.bool,
    expanded: PropTypes.bool,
    loading: PropTypes.bool,
    onDelete: PropTypes.func,
    onMore: PropTypes.func,
    onPointerEnter: PropTypes.func,
    onPointerLeave: PropTypes.func,
    onToggle: PropTypes.func,
    showMore: PropTypes.bool
};

Backpack.defaultProps = {
    blockDragOver: false,
    contents: [],
    dragOver: false,
    expanded: false,
    loading: false,
    showMore: false,
    onMore: null,
    onToggle: null
};

export default Backpack;
