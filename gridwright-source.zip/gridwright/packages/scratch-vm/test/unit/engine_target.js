const test = require('tap').test;
const Target = require('../../src/engine/target');
const Variable = require('../../src/engine/variable');
const adapter = require('../../src/engine/adapter');
const Runtime = require('../../src/engine/runtime');
const log = require('../../src/util/log');
const events = require('../fixtures/events.json');

test('spec', t => {
    const target = new Target(new Runtime());

    t.type(Target, 'function');
    t.type(target, 'object');
    t.ok(target instanceof Target);

    t.type(target.id, 'string');
    t.type(target.blocks, 'object');
    t.type(target.variables, 'object');
    t.type(target.comments, 'object');
    t.type(target._customState, 'object');

    t.type(target.createVariable, 'function');
    t.type(target.renameVariable, 'function');

    t.end();
});

// Create Variable tests.
test('createVariable', t => {
    const target = new Target(new Runtime());
    target.createVariable('foo', 'bar', Variable.SCALAR_TYPE);

    const variables = target.variables;
    t.equal(Object.keys(variables).length, 1);
    const variable = variables[Object.keys(variables)[0]];
    t.equal(variable.id, 'foo');
    t.equal(variable.name, 'bar');
    t.equal(variable.type, Variable.SCALAR_TYPE);
    t.equal(variable.value, 0);
    t.equal(variable.isCloud, false);

    t.end();
});

// Create Same Variable twice.
test('createVariable2', t => {
    const target = new Target(new Runtime());
    target.createVariable('foo', 'bar', Variable.SCALAR_TYPE);
    target.createVariable('foo', 'bar', Variable.SCALAR_TYPE);

    const variables = target.variables;
    t.equal(Object.keys(variables).length, 1);

    t.end();
});

// Create a list
test('createListVariable creates a list', t => {
    const target = new Target(new Runtime());
    target.createVariable('foo', 'bar', Variable.LIST_TYPE);

    const variables = target.variables;
    t.equal(Object.keys(variables).length, 1);
    const variable = variables[Object.keys(variables)[0]];
    t.equal(variable.id, 'foo');
    t.equal(variable.name, 'bar');
    t.equal(variable.type, Variable.LIST_TYPE);
    t.ok(variable.value instanceof Array, true);
    t.equal(variable.value.length, 0);
    t.equal(variable.isCloud, false);

    t.end();
});

test('createVariable calls cloud io device\'s requestCreateVariable', t => {
    const runtime = new Runtime();
    // Mock the requestCreateVariable function
    let requestCreateCloudWasCalled = false;
    runtime.ioDevices.cloud.requestCreateVariable = () => {
        requestCreateCloudWasCalled = true;
    };

    const target = new Target(runtime);
    target.isStage = true;
    target.createVariable('foo', 'bar', Variable.SCALAR_TYPE, true /* isCloud */);

    const variables = target.variables;
    t.equal(Object.keys(variables).length, 1);
    const variable = variables[Object.keys(variables)[0]];
    t.equal(variable.id, 'foo');
    t.equal(variable.name, 'bar');
    t.equal(variable.type, Variable.SCALAR_TYPE);
    t.equal(variable.value, 0);
    t.equal(variable.isCloud, true);
    t.equal(requestCreateCloudWasCalled, true);

    t.end();
});

test('createVariable does not call cloud io device\'s requestCreateVariable if target is not stage', t => {
    const runtime = new Runtime();
    // Mock the requestCreateVariable function
    let requestCreateCloudWasCalled = false;
    runtime.ioDevices.cloud.requestCreateVariable = () => {
        requestCreateCloudWasCalled = true;
    };

    const target = new Target(runtime);
    target.isStage = false;
    target.createVariable('foo', 'bar', Variable.SCALAR_TYPE, true /* isCloud */);

    const variables = target.variables;
    t.equal(Object.keys(variables).length, 1);
    const variable = variables[Object.keys(variables)[0]];
    t.equal(variable.id, 'foo');
    t.equal(variable.name, 'bar');
    t.equal(variable.type, Variable.SCALAR_TYPE);
    t.equal(variable.value, 0);
    // isCloud flag doesn't get set if the target is not the stage
    t.equal(variable.isCloud, false);
    t.equal(requestCreateCloudWasCalled, false);

    t.end();
});

test('createVariable throws when given invalid type', t => {
    const target = new Target(new Runtime());
    t.throws(
        (() => target.createVariable('foo', 'bar', 'baz')),
        new Error('Invalid variable type: baz')
    );

    t.end();
});

// Rename Variable tests.
test('renameVariable', t => {
    const target = new Target(new Runtime());
    target.createVariable('foo', 'bar', Variable.SCALAR_TYPE);
    target.renameVariable('foo', 'bar2');

    const variables = target.variables;
    t.equal(Object.keys(variables).length, 1);
    const variable = variables[Object.keys(variables)[0]];
    t.equal(variable.id, 'foo');
    t.equal(variable.name, 'bar2');
    t.equal(variable.value, 0);
    t.equal(variable.isCloud, false);

    t.end();
});

// Rename Variable that doesn't exist.
test('renameVariable2', t => {
    const target = new Target(new Runtime());
    target.renameVariable('foo', 'bar2');

    const variables = target.variables;
    t.equal(Object.keys(variables).length, 0);

    t.end();
});

// Rename Variable that with id that exists as another variable's name.
// Expect no change.
test('renameVariable3', t => {
    const target = new Target(new Runtime());
    target.createVariable('foo1', 'foo', Variable.SCALAR_TYPE);
    target.renameVariable('foo', 'bar2');

    const variables = target.variables;
    t.equal(Object.keys(variables).length, 1);
    const variable = variables[Object.keys(variables)[0]];
    t.equal(variable.id, 'foo1');
    t.equal(variable.name, 'foo');

    t.end();
});

test('renameVariable calls cloud io device\'s requestRenameVariable function', t => {
    const runtime = new Runtime();

    let requestRenameVariableWasCalled = false;
    runtime.ioDevices.cloud.requestRenameVariable = () => {
        requestRenameVariableWasCalled = true;
    };

    const target = new Target(runtime);
    target.isStage = true;
    const mockCloudVar = new Variable('foo', 'bar', Variable.SCALAR_TYPE, true);
    target.variables[mockCloudVar.id] = mockCloudVar;
    runtime.addTarget(target);

    target.renameVariable('foo', 'bar2');

    const variables = target.variables;
    t.equal(Object.keys(variables).length, 1);
    const variable = variables[Object.keys(variables)[0]];
    t.equal(variable.id, 'foo');
    t.equal(variable.name, 'bar2');
    t.equal(variable.value, 0);
    t.equal(variable.isCloud, true);
    t.equal(requestRenameVariableWasCalled, true);

    t.end();
});

test('renameVariable does not call cloud io device\'s requestRenameVariable function if target is not stage', t => {
    const runtime = new Runtime();

    let requestRenameVariableWasCalled = false;
    runtime.ioDevices.cloud.requestRenameVariable = () => {
        requestRenameVariableWasCalled = true;
    };

    const target = new Target(runtime);
    const mockCloudVar = new Variable('foo', 'bar', Variable.SCALAR_TYPE, true);
    target.variables[mockCloudVar.id] = mockCloudVar;
    runtime.addTarget(target);

    target.renameVariable('foo', 'bar2');

    const variables = target.variables;
    t.equal(Object.keys(variables).length, 1);
    const variable = variables[Object.keys(variables)[0]];
    t.equal(variable.id, 'foo');
    t.equal(variable.name, 'bar2');
    t.equal(variable.value, 0);
    t.equal(variable.isCloud, true);
    t.equal(requestRenameVariableWasCalled, false);

    t.end();
});

// Delete Variable tests.
test('deleteVariable', t => {
    const target = new Target(new Runtime());
    target.createVariable('foo', 'bar', Variable.SCALAR_TYPE);
    target.deleteVariable('foo');

    const variables = target.variables;
    t.equal(Object.keys(variables).length, 0);

    t.end();
});

// Delete Variable that doesn't exist.
test('deleteVariable2', t => {
    const target = new Target(new Runtime());
    target.deleteVariable('foo');

    const variables = target.variables;
    t.equal(Object.keys(variables).length, 0);

    t.end();
});

test('deleteVariable calls cloud io device\'s requestRenameVariable function', t => {
    const runtime = new Runtime();

    let requestDeleteVariableWasCalled = false;
    runtime.ioDevices.cloud.requestDeleteVariable = () => {
        requestDeleteVariableWasCalled = true;
    };

    const target = new Target(runtime);
    target.isStage = true;
    const mockCloudVar = new Variable('foo', 'bar', Variable.SCALAR_TYPE, true);
    target.variables[mockCloudVar.id] = mockCloudVar;
    runtime.addTarget(target);

    target.deleteVariable('foo');

    const variables = target.variables;
    t.equal(Object.keys(variables).length, 0);
    t.equal(requestDeleteVariableWasCalled, true);

    t.end();
});

test('deleteVariable calls cloud io device\'s requestRenameVariable function', t => {
    const runtime = new Runtime();

    let requestDeleteVariableWasCalled = false;
    runtime.ioDevices.cloud.requestDeleteVariable = () => {
        requestDeleteVariableWasCalled = true;
    };

    const target = new Target(runtime);
    const mockCloudVar = new Variable('foo', 'bar', Variable.SCALAR_TYPE, true);
    target.variables[mockCloudVar.id] = mockCloudVar;
    runtime.addTarget(target);

    target.deleteVariable('foo');

    const variables = target.variables;
    t.equal(Object.keys(variables).length, 0);
    t.equal(requestDeleteVariableWasCalled, false);

    t.end();
});

test('duplicateVariable creates a new variable with a new ID by default', t => {
    const target = new Target(new Runtime());
    target.createVariable('a var ID', 'foo', Variable.SCALAR_TYPE);
    t.equal(Object.keys(target.variables).length, 1);
    const originalVariable = target.variables['a var ID'];
    originalVariable.value = 10;
    const newVariable = target.duplicateVariable('a var ID');
    // Duplicating a variable should not add the variable to the current target
    t.equal(Object.keys(target.variables).length, 1);
    // Duplicate variable should have a different ID from the original unless specified to keep the original ID.
    t.not(newVariable.id, 'a var ID');
    t.type(target.variables[newVariable.id], 'undefined');

    // Duplicate variable should start out with the same value as the original variable
    t.equal(newVariable.value, originalVariable.value);

    // Modifying one variable should not modify the other
    newVariable.value = 15;
    t.not(newVariable.value, originalVariable.value);
    t.equal(originalVariable.value, 10);

    t.end();
});

test('duplicateVariable creates new array reference for list variable.value', t => {
    const target = new Target(new Runtime());
    const arr = [1, 2, 3];
    target.createVariable('a var ID', 'arr', Variable.LIST_TYPE);
    const originalVariable = target.variables['a var ID'];
    originalVariable.value = arr;
    const newVariable = target.duplicateVariable('a var ID');
    // Values are deeply equal but not the same object
    t.same(originalVariable.value, newVariable.value);
    t.not(originalVariable.value, newVariable.value);
    t.end();
});

test('duplicateVariable creates a new variable with a original ID if specified', t => {
    const target = new Target(new Runtime());
    target.createVariable('a var ID', 'foo', Variable.SCALAR_TYPE);
    t.equal(Object.keys(target.variables).length, 1);
    const originalVariable = target.variables['a var ID'];
    originalVariable.value = 10;
    const newVariable = target.duplicateVariable('a var ID', true);
    // Duplicating a variable should not add the variable to the current target
    t.equal(Object.keys(target.variables).length, 1);
    // Duplicate variable should have the same ID as the original when specified
    t.equal(newVariable.id, 'a var ID');

    // Duplicate variable should start out with the same value as the original variable
    t.equal(newVariable.value, originalVariable.value);

    // Modifying one variable should not modify the other
    newVariable.value = 15;
    t.not(newVariable.value, originalVariable.value);
    t.equal(originalVariable.value, 10);
    // The target should still have the original variable with the original value
    t.equal(target.variables['a var ID'].value, 10);

    t.end();
});

test('duplicateVariable returns null if variable with specified ID does not exist', t => {
    const target = new Target(new Runtime());

    const variable = target.duplicateVariable('a var ID');
    t.equal(variable, null);
    t.equal(Object.keys(target.variables).length, 0);

    target.createVariable('var id', 'foo', Variable.SCALAR_TYPE);
    t.equal(Object.keys(target.variables).length, 1);

    const anotherVariable = target.duplicateVariable('another var ID');
    t.equal(anotherVariable, null);
    t.equal(Object.keys(target.variables).length, 1);
    t.type(target.variables['another var ID'], 'undefined');
    t.type(target.variables['var id'], 'object');
    t.not(target.variables['var id'], null);

    t.end();
});

test('duplicateVariables duplicates all variables', t => {
    const target = new Target(new Runtime());
    target.createVariable('var ID 1', 'var1', Variable.SCALAR_TYPE);
    target.createVariable('var ID 2', 'var2', Variable.SCALAR_TYPE);

    t.equal(Object.keys(target.variables).length, 2);

    const var1 = target.variables['var ID 1'];
    const var2 = target.variables['var ID 2'];

    var1.value = 3;
    var2.value = 'foo';

    const duplicateVariables = target.duplicateVariables();

    // Duplicating a target's variables should not change the target's own variables.
    t.equal(Object.keys(target.variables).length, 2);
    t.equal(Object.keys(duplicateVariables).length, 2);

    // Should be able to find original var IDs in both this target's variables and
    // the duplicate variables since a blocks container was not specified.
    t.equal(Object.prototype.hasOwnProperty.call(target.variables, 'var ID 1'), true);
    t.equal(Object.prototype.hasOwnProperty.call(target.variables, 'var ID 2'), true);
    t.equal(Object.prototype.hasOwnProperty.call(duplicateVariables, 'var ID 1'), true);
    t.equal(Object.prototype.hasOwnProperty.call(duplicateVariables, 'var ID 1'), true);

    // Values of the duplicate variables should match the value of the original values at the time of duplication
    t.equal(target.variables['var ID 1'].value, duplicateVariables['var ID 1'].value);
    t.equal(duplicateVariables['var ID 1'].value, 3);
    t.equal(target.variables['var ID 2'].value, duplicateVariables['var ID 2'].value);
    t.equal(duplicateVariables['var ID 2'].value, 'foo');

    // The two sets of variables should still be distinct, modifying the target's variables
    // should not affect the duplicated variables, and vice-versa

    var1.value = 10;
    t.equal(target.variables['var ID 1'].value, 10);
    t.equal(duplicateVariables['var ID 1'].value, 3); // should remain unchanged from initial value

    duplicateVariables['var ID 2'].value = 'bar';
    t.equal(target.variables['var ID 2'].value, 'foo');

    // Deleting a variable on the target should not change the duplicated variables
    target.deleteVariable('var ID 1');
    t.equal(Object.keys(target.variables).length, 1);
    t.equal(Object.keys(duplicateVariables).length, 2);
    t.type(duplicateVariables['var ID 1'], 'object');
    t.not(duplicateVariables['var ID 1'], null);

    t.end();
});

test('duplicateVariables re-IDs variables when a block container is provided', t => {
    const target = new Target(new Runtime());

    target.createVariable('mock var id', 'a mock variable', Variable.SCALAR_TYPE);
    target.createVariable('another var id', 'var2', Variable.SCALAR_TYPE);

    // Create a block on the target which references the variable with id 'mock var id'
    target.blocks.createBlock(adapter(events.mockVariableBlock)[0]);

    t.type(target.blocks.getBlock('a block'), 'object');
    t.type(target.blocks.getBlock('a block').fields.VARIABLE, 'object');
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.id, 'mock var id');
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.value, 'a mock variable');

    // Deep clone this target's blocks to pass in to 'duplicateVariables'
    const copiedBlocks = target.blocks.duplicate();

    // The copied block should still have the same ID, and its VARIABLE field should still refer to
    // the original variable id
    t.type(copiedBlocks.getBlock('a block'), 'object');
    t.type(copiedBlocks.getBlock('a block').fields.VARIABLE, 'object');
    t.equal(copiedBlocks.getBlock('a block').fields.VARIABLE.id, 'mock var id');
    t.equal(copiedBlocks.getBlock('a block').fields.VARIABLE.value, 'a mock variable');

    const duplicateVariables = target.duplicateVariables(copiedBlocks);

    // Duplicate variables should have new IDs
    t.equal(Object.keys(duplicateVariables).length, 2);
    t.type(duplicateVariables['mock var id'], 'undefined');
    t.type(duplicateVariables['another var id'], 'undefined');

    // Duplicate variables still have the same names..
    const dupes = Object.values(duplicateVariables);
    const dupeVarNames = dupes.map(v => v.name);

    t.not(dupeVarNames.indexOf('a mock variable'), -1);
    t.not(dupeVarNames.indexOf('var2'), -1);

    // Duplicating variables should not change blocks on current target
    t.type(target.blocks.getBlock('a block'), 'object');
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.id, 'mock var id');
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.value, 'a mock variable');

    // The copied blocks passed into duplicateVariables should now reference the new
    // variable ID
    const mockVariableDupe = dupes[dupeVarNames.indexOf('a mock variable')];
    const mockVarDupeID = mockVariableDupe.id;

    t.type(copiedBlocks.getBlock('a block'), 'object');
    t.equal(copiedBlocks.getBlock('a block').fields.VARIABLE.id, mockVarDupeID);
    t.equal(copiedBlocks.getBlock('a block').fields.VARIABLE.value, 'a mock variable');

    t.end();
});

test('lookupOrCreateList creates a list if var with given id or var with given name does not exist', t => {
    const target = new Target(new Runtime());
    const variables = target.variables;

    t.equal(Object.keys(variables).length, 0);
    const listVar = target.lookupOrCreateList('foo', 'bar');
    t.equal(Object.keys(variables).length, 1);
    t.equal(listVar.id, 'foo');
    t.equal(listVar.name, 'bar');

    t.end();
});

test('lookupOrCreateList returns list if one with given id exists', t => {
    const target = new Target(new Runtime());
    const variables = target.variables;

    t.equal(Object.keys(variables).length, 0);
    target.createVariable('foo', 'bar', Variable.LIST_TYPE);
    t.equal(Object.keys(variables).length, 1);

    const listVar = target.lookupOrCreateList('foo', 'bar');
    t.equal(Object.keys(variables).length, 1);
    t.equal(listVar.id, 'foo');
    t.equal(listVar.name, 'bar');

    t.end();
});

test('lookupOrCreateList succeeds in finding list if id is incorrect but name matches', t => {
    const target = new Target(new Runtime());
    const variables = target.variables;

    t.equal(Object.keys(variables).length, 0);
    target.createVariable('foo', 'bar', Variable.LIST_TYPE);
    t.equal(Object.keys(variables).length, 1);

    const listVar = target.lookupOrCreateList('not foo', 'bar');
    t.equal(Object.keys(variables).length, 1);
    t.equal(listVar.id, 'foo');
    t.equal(listVar.name, 'bar');

    t.end();
});

test('lookupBroadcastMsg returns the var with given id if exists', t => {
    const target = new Target(new Runtime());
    const variables = target.variables;

    t.equal(Object.keys(variables).length, 0);
    target.createVariable('foo', 'bar', Variable.BROADCAST_MESSAGE_TYPE);
    t.equal(Object.keys(variables).length, 1);

    const broadcastMsg = target.lookupBroadcastMsg('foo', 'bar');
    t.equal(Object.keys(variables).length, 1);
    t.equal(broadcastMsg.id, 'foo');
    t.equal(broadcastMsg.name, 'bar');

    t.end();
});

test('createComment adds a comment to the target', t => {
    const target = new Target(new Runtime());
    const comments = target.comments;

    t.equal(Object.keys(comments).length, 0);
    target.createComment('a comment', null, 'some comment text',
        10, 20, 200, 300, true);
    t.equal(Object.keys(comments).length, 1);

    const comment = comments['a comment'];
    t.not(comment, null);
    t.equal(comment.blockId, null);
    t.equal(comment.text, 'some comment text');
    t.equal(comment.x, 10);
    t.equal(comment.y, 20);
    t.equal(comment.width, 200);
    t.equal(comment.height, 300);
    t.equal(comment.minimized, true);

    t.end();
});

test('creating comment with id that already exists does not change existing comment', t => {
    const target = new Target(new Runtime());
    const comments = target.comments;

    t.equal(Object.keys(comments).length, 0);
    target.createComment('a comment', null, 'some comment text',
        10, 20, 200, 300, true);
    t.equal(Object.keys(comments).length, 1);

    target.createComment('a comment', null,
        'some new comment text', 40, 50, 300, 400, false);

    const comment = comments['a comment'];
    t.not(comment, null);
    // All of the comment properties should remain unchanged from the first
    // time createComment was called
    t.equal(comment.blockId, null);
    t.equal(comment.text, 'some comment text');
    t.equal(comment.x, 10);
    t.equal(comment.y, 20);
    t.equal(comment.width, 200);
    t.equal(comment.height, 300);
    t.equal(comment.minimized, true);

    t.end();
});

test('creating a comment with a blockId also updates the comment property on the block', t => {
    const target = new Target(new Runtime());
    const comments = target.comments;
    // Create a mock block on the target
    target.blocks = {
        'a mock block': {
            id: 'a mock block'
        }
    };

    // Mock the getBlock function that's used in commentCreate
    target.blocks.getBlock = id => target.blocks[id];

    t.equal(Object.keys(comments).length, 0);
    target.createComment('a comment', 'a mock block', 'some comment text',
        10, 20, 200, 300, true);
    t.equal(Object.keys(comments).length, 1);

    const comment = comments['a comment'];
    t.equal(comment.blockId, 'a mock block');
    t.equal(target.blocks.getBlock('a mock block').comment, 'a comment');

    t.end();
});

test('fixUpVariableReferences fixes sprite global var conflicting with project global var', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;

    runtime.targets = [stage, target];

    // Create a global variable
    stage.createVariable('pre-existing global var id', 'a mock variable', Variable.SCALAR_TYPE);

    target.blocks.createBlock(adapter(events.mockVariableBlock)[0]);

    t.equal(Object.keys(target.variables).length, 0);
    t.equal(Object.keys(stage.variables).length, 1);
    t.type(target.blocks.getBlock('a block'), 'object');
    t.type(target.blocks.getBlock('a block').fields, 'object');
    t.type(target.blocks.getBlock('a block').fields.VARIABLE, 'object');
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.id, 'mock var id');

    target.fixUpVariableReferences();

    t.equal(Object.keys(target.variables).length, 0);
    t.equal(Object.keys(stage.variables).length, 1);
    t.type(target.blocks.getBlock('a block'), 'object');
    t.type(target.blocks.getBlock('a block').fields, 'object');
    t.type(target.blocks.getBlock('a block').fields.VARIABLE, 'object');
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.id, 'pre-existing global var id');

    t.end();
});

test('fixUpVariableReferences fixes sprite local var conflicting with project global var', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    // Create a global variable
    stage.createVariable('pre-existing global var id', 'a mock variable', Variable.SCALAR_TYPE);
    target.createVariable('mock var id', 'a mock variable', Variable.SCALAR_TYPE);

    target.blocks.createBlock(adapter(events.mockVariableBlock)[0]);

    t.equal(Object.keys(target.variables).length, 1);
    t.equal(Object.keys(stage.variables).length, 1);
    t.type(target.blocks.getBlock('a block'), 'object');
    t.type(target.blocks.getBlock('a block').fields, 'object');
    t.type(target.blocks.getBlock('a block').fields.VARIABLE, 'object');
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.id, 'mock var id');
    t.equal(target.variables['mock var id'].name, 'a mock variable');

    target.fixUpVariableReferences();

    t.equal(Object.keys(target.variables).length, 1);
    t.equal(Object.keys(stage.variables).length, 1);
    t.type(target.blocks.getBlock('a block'), 'object');
    t.type(target.blocks.getBlock('a block').fields, 'object');
    t.type(target.blocks.getBlock('a block').fields.VARIABLE, 'object');
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.id, 'mock var id');
    t.equal(target.variables['mock var id'].name, 'Target: a mock variable');

    t.end();
});

test('fixUpVariableReferences fixes conflicting sprite local var without blocks referencing var', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    // Create a global variable
    stage.createVariable('pre-existing global var id', 'a mock variable', Variable.SCALAR_TYPE);
    target.createVariable('mock var id', 'a mock variable', Variable.SCALAR_TYPE);


    t.equal(Object.keys(target.variables).length, 1);
    t.equal(Object.keys(stage.variables).length, 1);
    t.equal(target.variables['mock var id'].name, 'a mock variable');

    target.fixUpVariableReferences();

    t.equal(Object.keys(target.variables).length, 1);
    t.equal(Object.keys(stage.variables).length, 1);
    t.equal(target.variables['mock var id'].name, 'Target: a mock variable');

    t.end();
});

test('fixUpVariableReferences fixes sprite global var conflicting with other sprite\'s local var', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;

    const existingTarget = new Target(runtime);
    existingTarget.isStage = false;

    runtime.targets = [stage, target, existingTarget];

    // Create a local variable on the pre-existing target
    existingTarget.createVariable('pre-existing local var id', 'a mock variable', Variable.SCALAR_TYPE);

    target.blocks.createBlock(adapter(events.mockVariableBlock)[0]);

    t.equal(Object.keys(existingTarget.variables).length, 1);
    const existingVariable = Object.values(existingTarget.variables)[0];
    t.equal(existingVariable.name, 'a mock variable');
    t.equal(Object.keys(target.variables).length, 0);
    t.equal(Object.keys(stage.variables).length, 0);
    t.type(target.blocks.getBlock('a block'), 'object');
    t.type(target.blocks.getBlock('a block').fields, 'object');
    t.type(target.blocks.getBlock('a block').fields.VARIABLE, 'object');
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.id, 'mock var id');

    target.fixUpVariableReferences();

    t.equal(Object.keys(existingTarget.variables).length, 1);
    t.equal(existingVariable.name, 'a mock variable');
    t.equal(Object.keys(target.variables).length, 0);
    t.equal(Object.keys(stage.variables).length, 1);
    t.type(target.blocks.getBlock('a block'), 'object');
    t.type(target.blocks.getBlock('a block').fields, 'object');
    t.type(target.blocks.getBlock('a block').fields.VARIABLE, 'object');
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.id, 'mock var id');
    const newGlobal = stage.variables[Object.keys(stage.variables)[0]];
    t.equal(newGlobal.name, 'a mock variable2');

    t.end();
});

test('fixUpVariableReferences does not change variable name if there is no variable conflict', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    // Create a global variable
    stage.createVariable('pre-existing global var id', 'a variable', Variable.SCALAR_TYPE);
    stage.createVariable('pre-existing global list id', 'a mock variable', Variable.LIST_TYPE);
    target.createVariable('mock var id', 'a mock variable', Variable.SCALAR_TYPE);

    target.blocks.createBlock(adapter(events.mockVariableBlock)[0]);

    t.equal(Object.keys(target.variables).length, 1);
    t.equal(Object.keys(stage.variables).length, 2);
    t.type(target.blocks.getBlock('a block'), 'object');
    t.type(target.blocks.getBlock('a block').fields, 'object');
    t.type(target.blocks.getBlock('a block').fields.VARIABLE, 'object');
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.id, 'mock var id');
    t.equal(target.variables['mock var id'].name, 'a mock variable');

    target.fixUpVariableReferences();

    t.equal(Object.keys(target.variables).length, 1);
    t.equal(Object.keys(stage.variables).length, 2);
    t.type(target.blocks.getBlock('a block'), 'object');
    t.type(target.blocks.getBlock('a block').fields, 'object');
    t.type(target.blocks.getBlock('a block').fields.VARIABLE, 'object');
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.id, 'mock var id');
    t.equal(target.variables['mock var id'].name, 'a mock variable');

    t.end();
});

const addBroadcastBlocksTo = target => {
    adapter(events.mockBroadcastBlock).forEach(block => target.blocks.createBlock(block));
};

test('fixUpVariableReferences creates a stage broadcast for an undefined broadcast reference', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    addBroadcastBlocksTo(target);

    t.equal(Object.keys(stage.variables).length, 0);
    t.equal(target.blocks.getBlock('boadcast shadow').fields.BROADCAST_OPTION.id, 'mock broadcast message id');
    t.equal(target.blocks.getBlock('boadcast shadow').fields.BROADCAST_OPTION.value, 'my message');

    target.fixUpVariableReferences();

    t.equal(Object.keys(stage.variables).length, 1);
    const broadcast = stage.variables['mock broadcast message id'];
    t.ok(broadcast, 'broadcast created on stage with original id');
    t.equal(broadcast.name, 'my message');
    t.equal(broadcast.type, Variable.BROADCAST_MESSAGE_TYPE);
    t.equal(target.blocks.getBlock('boadcast shadow').fields.BROADCAST_OPTION.id, 'mock broadcast message id');

    t.end();
});

test('fixUpVariableReferences remaps a broadcast reference to an existing same-name stage broadcast', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    stage.createVariable('pre-existing broadcast id', 'my message', Variable.BROADCAST_MESSAGE_TYPE);
    addBroadcastBlocksTo(target);

    t.equal(Object.keys(stage.variables).length, 1);
    t.equal(target.blocks.getBlock('boadcast shadow').fields.BROADCAST_OPTION.id, 'mock broadcast message id');

    target.fixUpVariableReferences();

    t.equal(Object.keys(stage.variables).length, 1, 'no duplicate broadcast created');
    t.ok(stage.variables['pre-existing broadcast id'], 'existing broadcast preserved');
    t.equal(target.blocks.getBlock('boadcast shadow').fields.BROADCAST_OPTION.id, 'pre-existing broadcast id',
        'block field id remapped to existing broadcast');

    t.end();
});

test('fixUpVariableReferences is idempotent for broadcast references', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    addBroadcastBlocksTo(target);

    target.fixUpVariableReferences();
    const stageVarsAfterFirst = Object.keys(stage.variables).slice();
    const fieldIdAfterFirst = target.blocks.getBlock('boadcast shadow').fields.BROADCAST_OPTION.id;

    target.fixUpVariableReferences();

    t.same(Object.keys(stage.variables), stageVarsAfterFirst, 'no new stage broadcasts on second call');
    t.equal(target.blocks.getBlock('boadcast shadow').fields.BROADCAST_OPTION.id, fieldIdAfterFirst,
        'field id unchanged on second call');

    t.end();
});

test('fixUpVariableReferences on the stage does not rename existing stage variables', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;
    stage.getName = () => 'Stage';

    runtime.targets = [stage];

    stage.createVariable('pre-existing global var id', 'a stage variable', Variable.SCALAR_TYPE);
    stage.blocks.createBlock({
        id: 'a stage block',
        opcode: 'data_variable',
        inputs: {},
        fields: {
            VARIABLE: {
                name: 'VARIABLE',
                id: 'pre-existing global var id',
                value: 'a stage variable',
                variableType: Variable.SCALAR_TYPE
            }
        },
        next: null,
        topLevel: true,
        parent: null,
        shadow: false,
        x: 0,
        y: 0
    });

    stage.fixUpVariableReferences();

    t.equal(Object.keys(stage.variables).length, 1, 'no duplicate stage variable');
    t.equal(stage.variables['pre-existing global var id'].name, 'a stage variable',
        'existing stage variable name not changed');
    t.equal(stage.blocks.getBlock('a stage block').fields.VARIABLE.id, 'pre-existing global var id',
        'block field id unchanged');

    t.end();
});

test('fixUpVariableReferences on the stage creates broadcasts for undefined references', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;
    stage.getName = () => 'Stage';

    runtime.targets = [stage];

    addBroadcastBlocksTo(stage);

    t.equal(Object.keys(stage.variables).length, 0);

    stage.fixUpVariableReferences();

    t.equal(Object.keys(stage.variables).length, 1);
    const broadcast = stage.variables['mock broadcast message id'];
    t.ok(broadcast, 'broadcast created on stage');
    t.equal(broadcast.name, 'my message');
    t.equal(broadcast.type, Variable.BROADCAST_MESSAGE_TYPE);

    t.end();
});

test('reconcileVariableReferences creates a sprite-local variable for an undefined variable reference', t => {
    // Project load: match what lookupOrCreateVariable would have done when the block
    // first executed, which is to create the variable on the sprite under its own name.
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    target.blocks.createBlock(adapter(events.mockVariableBlock)[0]);

    t.equal(Object.keys(stage.variables).length, 0);
    t.equal(Object.keys(target.variables).length, 0);

    target.reconcileVariableReferences();

    t.equal(Object.keys(stage.variables).length, 0, 'no variable created on stage');
    t.equal(Object.keys(target.variables).length, 1, 'variable created on the sprite');
    const newVar = target.variables['mock var id'];
    t.ok(newVar, 'variable preserves the original id');
    t.equal(newVar.name, 'a mock variable');
    t.equal(newVar.type, Variable.SCALAR_TYPE);
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.id, 'mock var id');
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.value, 'a mock variable');

    t.end();
});

test('reconcileVariableReferences with createMissingOnStage creates a stage variable', t => {
    // Sprite import and backpack paste: an exported sprite carries its own locals, so an
    // undefined reference must have been a global in the project it came from.
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    target.blocks.createBlock(adapter(events.mockVariableBlock)[0]);

    t.equal(Object.keys(stage.variables).length, 0);
    t.equal(Object.keys(target.variables).length, 0);

    target.reconcileVariableReferences(true);

    t.equal(Object.keys(stage.variables).length, 1, 'variable created on stage');
    const newVar = stage.variables['mock var id'];
    t.ok(newVar, 'variable preserves the original id');
    t.equal(newVar.name, 'a mock variable');
    t.equal(newVar.type, Variable.SCALAR_TYPE);
    t.equal(Object.keys(target.variables).length, 0, 'no variable on the sprite');
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.id, 'mock var id');

    t.end();
});

test('reconcileVariableReferences creates a sprite-local list for an undefined list reference', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    target.blocks.createBlock(adapter(events.mockListBlock)[0]);

    t.equal(Object.keys(stage.variables).length, 0);
    t.equal(target.blocks.getBlock('another block').fields.LIST.id, 'mock list id');
    t.equal(target.blocks.getBlock('another block').fields.LIST.value, 'a mock list');

    target.reconcileVariableReferences();

    t.equal(Object.keys(stage.variables).length, 0, 'no list created on stage');
    t.equal(Object.keys(target.variables).length, 1, 'list created on the sprite');
    const newList = target.variables['mock list id'];
    t.ok(newList, 'list preserves the original id');
    t.equal(newList.name, 'a mock list');
    t.equal(newList.type, Variable.LIST_TYPE);
    t.equal(target.blocks.getBlock('another block').fields.LIST.id, 'mock list id');

    t.end();
});

test('reconcileVariableReferences with createMissingOnStage creates a stage list', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    target.blocks.createBlock(adapter(events.mockListBlock)[0]);

    t.equal(Object.keys(stage.variables).length, 0);

    target.reconcileVariableReferences(true);

    t.equal(Object.keys(stage.variables).length, 1, 'list created on stage');
    const newList = stage.variables['mock list id'];
    t.ok(newList, 'list preserves the original id');
    t.equal(newList.name, 'a mock list');
    t.equal(newList.type, Variable.LIST_TYPE);
    t.equal(Object.keys(target.variables).length, 0, 'no list on the sprite');
    t.equal(target.blocks.getBlock('another block').fields.LIST.id, 'mock list id');

    t.end();
});

test('reconcileVariableReferences remaps a list reference to an existing same-name stage list', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    stage.createVariable('pre-existing list id', 'a mock list', Variable.LIST_TYPE);
    target.blocks.createBlock(adapter(events.mockListBlock)[0]);

    target.reconcileVariableReferences();

    t.equal(Object.keys(stage.variables).length, 1, 'no duplicate list created');
    t.ok(stage.variables['pre-existing list id'], 'existing list preserved');
    t.equal(target.blocks.getBlock('another block').fields.LIST.id, 'pre-existing list id',
        'block field id remapped to existing list');

    t.end();
});

test('reconcileVariableReferences creates a stage broadcast for an undefined broadcast reference', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    addBroadcastBlocksTo(target);

    t.equal(Object.keys(stage.variables).length, 0);

    target.reconcileVariableReferences();

    t.equal(Object.keys(stage.variables).length, 1);
    const broadcast = stage.variables['mock broadcast message id'];
    t.ok(broadcast, 'broadcast created on stage');
    t.equal(broadcast.name, 'my message');
    t.equal(broadcast.type, Variable.BROADCAST_MESSAGE_TYPE);
    t.equal(target.blocks.getBlock('boadcast shadow').fields.BROADCAST_OPTION.id, 'mock broadcast message id');

    t.end();
});

test('reconcileVariableReferences remaps to an existing same-name stage variable', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    stage.createVariable('pre-existing global var id', 'a mock variable', Variable.SCALAR_TYPE);
    target.blocks.createBlock(adapter(events.mockVariableBlock)[0]);

    target.reconcileVariableReferences();

    t.equal(Object.keys(stage.variables).length, 1, 'no duplicate created');
    t.ok(stage.variables['pre-existing global var id'], 'existing variable preserved');
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.id, 'pre-existing global var id',
        'block field id remapped to existing variable');

    t.end();
});

test('reconcileVariableReferences is idempotent', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    addBroadcastBlocksTo(target);

    target.reconcileVariableReferences();
    const stageVarsAfterFirst = Object.keys(stage.variables).slice();
    const fieldIdAfterFirst = target.blocks.getBlock('boadcast shadow').fields.BROADCAST_OPTION.id;

    target.reconcileVariableReferences();

    t.same(Object.keys(stage.variables), stageVarsAfterFirst, 'no new stage variables on second call');
    t.equal(target.blocks.getBlock('boadcast shadow').fields.BROADCAST_OPTION.id, fieldIdAfterFirst,
        'field id unchanged on second call');

    t.end();
});

test('reconcileVariableReferences does NOT rename a sprite local that name-collides with a stage global', t => {
    // This is the critical regression test that distinguishes reconcileVariableReferences from
    // fixUpVariableReferences. Project load runs only the repair-only helper on every target;
    // legitimate local-vs-global name collisions (a Scratch configuration that has always been
    // valid) must not be touched.
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    stage.createVariable('global var id', 'a mock variable', Variable.SCALAR_TYPE);
    target.createVariable('mock var id', 'a mock variable', Variable.SCALAR_TYPE);
    target.blocks.createBlock(adapter(events.mockVariableBlock)[0]);

    target.reconcileVariableReferences();

    t.equal(target.variables['mock var id'].name, 'a mock variable',
        'sprite local variable not renamed by reconcile');
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.id, 'mock var id',
        'block field id unchanged');
    t.equal(Object.keys(stage.variables).length, 1, 'no new stage variables created');

    t.end();
});

test('reconcileVariableReferences on the stage creates broadcasts for undefined references', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;
    stage.getName = () => 'Stage';

    runtime.targets = [stage];

    addBroadcastBlocksTo(stage);

    t.equal(Object.keys(stage.variables).length, 0);

    stage.reconcileVariableReferences();

    t.equal(Object.keys(stage.variables).length, 1);
    const broadcast = stage.variables['mock broadcast message id'];
    t.ok(broadcast);
    t.equal(broadcast.name, 'my message');
    t.equal(broadcast.type, Variable.BROADCAST_MESSAGE_TYPE);

    t.end();
});

const captureLogWarn = (fn) => {
    const original = log.warn;
    const messages = [];
    log.warn = (...args) => messages.push(args.join(' '));
    try {
        fn();
    } finally {
        log.warn = original;
    }
    return messages;
};

test('reconcileVariableReferences emits log.warn when it creates a stage definition', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    addBroadcastBlocksTo(target);

    const messages = captureLogWarn(() => target.reconcileVariableReferences());

    t.equal(messages.length, 1, 'one log.warn fired');
    t.match(messages[0], /Reconciled.*'Target'.*created.*'mock broadcast message id'/,
        'log message names the target and the created definition');

    t.end();
});

test('reconcileVariableReferences emits log.warn when it remaps a reference', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    stage.createVariable('pre-existing global var id', 'a mock variable', Variable.SCALAR_TYPE);
    target.blocks.createBlock(adapter(events.mockVariableBlock)[0]);

    const messages = captureLogWarn(() => target.reconcileVariableReferences());

    t.equal(messages.length, 1, 'one log.warn fired');
    t.match(messages[0], /Reconciled.*remapped.*'mock var id'.*'pre-existing global var id'/,
        'log message names the remap');

    t.end();
});

test('reconcileVariableReferences coalesces same-original-name dangling refs to one stage variable', t => {
    // Regression for an issue caught in review: when two dangling refs share an
    // original name+type and the name has to be bumped (because some other target
    // already uses it), the second ref must coalesce with the first rather than
    // create a second stage variable. A Scratcher who pasted two scripts referencing
    // what they called "score" almost certainly meant one variable, not two.
    // Bumping only happens on the createMissingOnStage (sprite import) path.
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    // Another sprite owns a local variable with the same name, forcing unusedName to bump.
    const otherSprite = new Target(runtime);
    otherSprite.isStage = false;
    otherSprite.getName = () => 'Other';
    otherSprite.createVariable('other local id', 'shared name', Variable.SCALAR_TYPE);

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, otherSprite, target];

    // Two dangling refs with the same original name+type, distinct ids.
    target.blocks.createBlock({
        id: 'block A',
        opcode: 'data_variable',
        inputs: {},
        fields: {
            VARIABLE: {
                name: 'VARIABLE',
                id: 'dangling A',
                value: 'shared name',
                variableType: Variable.SCALAR_TYPE
            }
        },
        next: null,
        topLevel: true,
        parent: null,
        shadow: false,
        x: 0,
        y: 0
    });
    target.blocks.createBlock({
        id: 'block B',
        opcode: 'data_variable',
        inputs: {},
        fields: {
            VARIABLE: {
                name: 'VARIABLE',
                id: 'dangling B',
                value: 'shared name',
                variableType: Variable.SCALAR_TYPE
            }
        },
        next: null,
        topLevel: true,
        parent: null,
        shadow: false,
        x: 0,
        y: 0
    });

    target.reconcileVariableReferences(true);

    const stageVars = Object.values(stage.variables);
    t.equal(stageVars.length, 1, 'exactly one new stage variable was created');
    const created = stageVars[0];
    t.equal(created.type, Variable.SCALAR_TYPE);
    t.not(created.name, 'shared name', 'name was bumped to avoid the existing local');

    // Both block fields should now point to the same created stage variable
    // and display the same (bumped) name, otherwise users see one block named
    // "shared name" and another named "shared name2" pointing at the same variable.
    const fieldA = target.blocks.getBlock('block A').fields.VARIABLE;
    const fieldB = target.blocks.getBlock('block B').fields.VARIABLE;
    t.equal(fieldA.id, created.id, 'first dangling ref points at the created stage variable');
    t.equal(fieldB.id, created.id, 'second dangling ref coalesces to the same stage variable');
    t.equal(fieldA.value, created.name, 'first field displays the bumped name');
    t.equal(fieldB.value, created.name, 'second field displays the same bumped name');

    t.end();
});

test('reconcileVariableReferences normalizes field values across targets after a bump', t => {
    // Regression: when target A's reconcile pass creates a stage variable with a
    // bumped name (because of an external collision), a later target B that
    // references the same id by lookup must have its block field's displayed name
    // normalized too — otherwise the same variable shows different names in
    // different sprites' blocks.
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;
    stage.getName = () => 'Stage';

    // External collision forces unusedName to bump (createMissingOnStage path only).
    const otherSprite = new Target(runtime);
    otherSprite.isStage = false;
    otherSprite.getName = () => 'Other';
    otherSprite.createVariable('other local id', 'shared name', Variable.SCALAR_TYPE);

    const targetA = new Target(runtime);
    targetA.isStage = false;
    targetA.getName = () => 'TargetA';

    const targetB = new Target(runtime);
    targetB.isStage = false;
    targetB.getName = () => 'TargetB';

    runtime.targets = [stage, otherSprite, targetA, targetB];

    const makeBlockReferencing = (blockId, fieldId, fieldValue) => ({
        id: blockId,
        opcode: 'data_variable',
        inputs: {},
        fields: {
            VARIABLE: {
                name: 'VARIABLE',
                id: fieldId,
                value: fieldValue,
                variableType: Variable.SCALAR_TYPE
            }
        },
        next: null,
        topLevel: true,
        parent: null,
        shadow: false,
        x: 0,
        y: 0
    });

    targetA.blocks.createBlock(makeBlockReferencing('block A', 'shared dangling id', 'shared name'));
    targetB.blocks.createBlock(makeBlockReferencing('block B', 'shared dangling id', 'shared name'));

    // Reconcile each target in turn on the stage-creation path (the sprite-import
    // behavior; whole-project load never bumps names, so it cannot hit this case).
    targetA.reconcileVariableReferences(true);
    targetB.reconcileVariableReferences(true);

    const stageVars = Object.values(stage.variables);
    t.equal(stageVars.length, 1, 'one stage variable created across both targets');
    const created = stageVars[0];
    t.not(created.name, 'shared name', 'name was bumped');

    const fieldA = targetA.blocks.getBlock('block A').fields.VARIABLE;
    const fieldB = targetB.blocks.getBlock('block B').fields.VARIABLE;
    t.equal(fieldA.value, created.name, 'target A field value matches the resolved variable name');
    t.equal(fieldB.value, created.name, 'target B field value matches the resolved variable name');

    t.end();
});

const makeVariableFieldBlock = (blockId, opcode, fieldId, fieldValue) => ({
    id: blockId,
    opcode,
    inputs: {},
    fields: {
        VARIABLE: {
            name: 'VARIABLE',
            id: fieldId,
            value: fieldValue,
            variableType: Variable.SCALAR_TYPE
        }
    },
    next: null,
    topLevel: true,
    parent: null,
    shadow: false,
    x: 0,
    y: 0
});

test('reconcileVariableReferences remaps a dangling reference to a same-name sprite-local variable', t => {
    // Regression for scratchfoundation/scratch-editor#601. A sprite has a local "i"
    // and a "for each" block whose variable field carries a stale id but the name "i".
    // Before the repair-on-load existed, lookupOrCreateVariable resolved that field to
    // the local "i" by name at execution time. The repair must do the same rather
    // than minting a global "i2" and rewriting only the stale field to use it, which
    // left the loop counting "i2" while the loop body read "i".
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;
    stage.getName = () => 'Stage';

    // Another sprite also has a local "i", so a stage-side creation would have
    // had to bump the name (which is how "i2" appeared in the report).
    const otherSprite = new Target(runtime);
    otherSprite.isStage = false;
    otherSprite.getName = () => 'Other';
    otherSprite.createVariable('other i id', 'i', Variable.SCALAR_TYPE);

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'BSP';
    target.createVariable('local i id', 'i', Variable.SCALAR_TYPE);

    runtime.targets = [stage, otherSprite, target];

    target.blocks.createBlock(makeVariableFieldBlock('for each', 'control_for_each', 'stale i id', 'i'));
    target.blocks.createBlock(makeVariableFieldBlock('body', 'data_variable', 'local i id', 'i'));

    target.reconcileVariableReferences();

    t.equal(Object.keys(stage.variables).length, 0, 'no global created');
    t.same(Object.keys(target.variables), ['local i id'], 'no new local created');
    t.equal(target.variables['local i id'].name, 'i', 'local not renamed');
    t.equal(otherSprite.variables['other i id'].name, 'i', 'other sprite local not renamed');

    const loopField = target.blocks.getBlock('for each').fields.VARIABLE;
    const bodyField = target.blocks.getBlock('body').fields.VARIABLE;
    t.equal(loopField.id, 'local i id', 'stale reference remapped to the local');
    t.equal(loopField.value, 'i', 'loop field still displays "i"');
    t.equal(bodyField.id, 'local i id', 'clean reference untouched');
    t.equal(bodyField.value, 'i', 'body field still displays "i"');

    t.end();
});

test('reconcileVariableReferences prefers a same-name sprite-local over a same-name global', t => {
    // Same precedence as lookupVariableByNameAndType: locals first, then the stage.
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;
    stage.getName = () => 'Stage';
    stage.createVariable('global score id', 'score', Variable.SCALAR_TYPE);

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';
    target.createVariable('local score id', 'score', Variable.SCALAR_TYPE);

    runtime.targets = [stage, target];

    target.blocks.createBlock(makeVariableFieldBlock('a block', 'data_variable', 'stale score id', 'score'));

    target.reconcileVariableReferences();

    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.id, 'local score id',
        'stale reference remapped to the local, not the global');
    t.equal(Object.keys(stage.variables).length, 1, 'no new global');
    t.equal(Object.keys(target.variables).length, 1, 'no new local');

    t.end();
});

test('reconcileVariableReferences creates a local even when another sprite has a same-named local', t => {
    // Same-named locals on different sprites are an ordinary Scratch configuration,
    // so a locally-created definition keeps its name rather than being bumped.
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;
    stage.getName = () => 'Stage';

    const otherSprite = new Target(runtime);
    otherSprite.isStage = false;
    otherSprite.getName = () => 'Other';
    otherSprite.createVariable('other i id', 'i', Variable.SCALAR_TYPE);

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, otherSprite, target];

    target.blocks.createBlock(makeVariableFieldBlock('block A', 'data_variable', 'dangling A', 'i'));
    target.blocks.createBlock(makeVariableFieldBlock('block B', 'data_variable', 'dangling B', 'i'));

    target.reconcileVariableReferences();

    t.equal(Object.keys(stage.variables).length, 0, 'no global created');
    t.same(Object.keys(target.variables), ['dangling A'], 'one local created, keeping the first id');
    t.equal(target.variables['dangling A'].name, 'i', 'name not bumped');

    const fieldA = target.blocks.getBlock('block A').fields.VARIABLE;
    const fieldB = target.blocks.getBlock('block B').fields.VARIABLE;
    t.equal(fieldA.id, 'dangling A');
    t.equal(fieldB.id, 'dangling A', 'second dangling ref coalesces to the created local by name');
    t.equal(fieldA.value, 'i');
    t.equal(fieldB.value, 'i');

    t.end();
});

test('fixUpVariableReferences remaps a dangling reference to a same-name sprite-local variable', t => {
    // The sprite-import path shares the by-name resolution; only the create-when-missing
    // location differs.
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;
    stage.getName = () => 'Stage';

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';
    target.createVariable('local i id', 'i', Variable.SCALAR_TYPE);

    runtime.targets = [stage, target];

    target.blocks.createBlock(makeVariableFieldBlock('a block', 'data_variable', 'stale i id', 'i'));

    target.fixUpVariableReferences();

    t.equal(Object.keys(stage.variables).length, 0, 'no global created');
    t.same(Object.keys(target.variables), ['local i id'], 'no new local created');
    t.equal(target.variables['local i id'].name, 'i', 'local not renamed');
    t.equal(target.blocks.getBlock('a block').fields.VARIABLE.id, 'local i id', 'remapped to the local');

    t.end();
});

test('reconcileVariableReferences on the stage keeps the original name despite a same-named sprite local', t => {
    // A stage script with a dangling "i" while some sprite owns a local "i". The
    // runtime would have created a global "i" on first execution; bumping it to "i2"
    // would break name-based access such as a sensing block reading "i of Stage".
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;
    stage.getName = () => 'Stage';

    const sprite = new Target(runtime);
    sprite.isStage = false;
    sprite.getName = () => 'Sprite';
    sprite.createVariable('sprite i id', 'i', Variable.SCALAR_TYPE);

    runtime.targets = [stage, sprite];

    stage.blocks.createBlock(makeVariableFieldBlock('block A', 'data_variable', 'dangling A', 'i'));
    stage.blocks.createBlock(makeVariableFieldBlock('block B', 'data_variable', 'dangling B', 'i'));

    stage.reconcileVariableReferences();

    t.same(Object.keys(stage.variables), ['dangling A'], 'one global created, keeping the first id');
    t.equal(stage.variables['dangling A'].name, 'i', 'global keeps the original name');
    t.equal(sprite.variables['sprite i id'].name, 'i', 'sprite local untouched');

    const fieldA = stage.blocks.getBlock('block A').fields.VARIABLE;
    const fieldB = stage.blocks.getBlock('block B').fields.VARIABLE;
    t.equal(fieldA.id, 'dangling A');
    t.equal(fieldB.id, 'dangling A', 'second dangling ref coalesces to the created global by name');
    t.equal(fieldA.value, 'i');
    t.equal(fieldB.value, 'i');

    t.end();
});

test('reconcileVariableReferences with createMissingOnStage still bumps past a same-named sprite local', t => {
    // Sprite import keeps the historical behavior: a leftover reference becomes a
    // global whose name collides with nothing in the project.
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;
    stage.getName = () => 'Stage';

    const otherSprite = new Target(runtime);
    otherSprite.isStage = false;
    otherSprite.getName = () => 'Other';
    otherSprite.createVariable('other i id', 'i', Variable.SCALAR_TYPE);

    const imported = new Target(runtime);
    imported.isStage = false;
    imported.getName = () => 'Imported';

    runtime.targets = [stage, otherSprite, imported];

    imported.blocks.createBlock(makeVariableFieldBlock('a block', 'data_variable', 'dangling id', 'i'));

    imported.reconcileVariableReferences(true);

    t.same(Object.keys(stage.variables), ['dangling id'], 'global created');
    t.equal(stage.variables['dangling id'].name, 'i2', 'name bumped past the other sprite\'s local');
    t.equal(imported.blocks.getBlock('a block').fields.VARIABLE.value, 'i2', 'field shows the bumped name');
    t.equal(Object.keys(imported.variables).length, 0, 'nothing created on the imported sprite');

    t.end();
});

test('reconcileVariableReferences matches a dangling broadcast reference case-insensitively', t => {
    // Broadcast names are matched case-insensitively at runtime, so a dangling
    // "my message" should resolve to an existing "My Message" rather than create a
    // second broadcast that differs only in case.
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;
    stage.getName = () => 'Stage';

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    stage.createVariable('existing broadcast id', 'My Message', Variable.BROADCAST_MESSAGE_TYPE);
    addBroadcastBlocksTo(target);

    target.reconcileVariableReferences();

    t.same(Object.keys(stage.variables), ['existing broadcast id'], 'no second broadcast created');
    const field = target.blocks.getBlock('boadcast shadow').fields.BROADCAST_OPTION;
    t.equal(field.id, 'existing broadcast id', 'reference remapped to the existing broadcast');
    t.equal(field.value, 'My Message', 'field displays the existing broadcast\'s name');

    t.end();
});

test('reconcileVariableReferences keeps a cloud-prefixed missing variable on the sprite', t => {
    // The cloud prefix is an editor naming convention, not scope metadata. The
    // loader deliberately keeps a cloud-marked sprite-local as a regular local,
    // and lookupOrCreateVariable creates locally regardless of the name.
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;
    stage.getName = () => 'Stage';

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    target.blocks.createBlock(makeVariableFieldBlock('a block', 'data_variable', 'lost cloud id', '☁ score'));

    target.reconcileVariableReferences();

    t.equal(Object.keys(stage.variables).length, 0, 'nothing created on the stage');
    t.same(Object.keys(target.variables), ['lost cloud id'], 'created on the sprite');
    t.equal(target.variables['lost cloud id'].name, '☁ score');
    t.equal(target.variables['lost cloud id'].isCloud, false);

    t.end();
});

test('reconcileVariableReferences does not log on clean references', t => {
    const runtime = new Runtime();

    const stage = new Target(runtime);
    stage.isStage = true;

    const target = new Target(runtime);
    target.isStage = false;
    target.getName = () => 'Target';

    runtime.targets = [stage, target];

    stage.createVariable('mock var id', 'a mock variable', Variable.SCALAR_TYPE);
    target.blocks.createBlock(adapter(events.mockVariableBlock)[0]);

    const messages = captureLogWarn(() => target.reconcileVariableReferences());

    t.equal(messages.length, 0, 'no log.warn fired on a clean reference');

    t.end();
});
